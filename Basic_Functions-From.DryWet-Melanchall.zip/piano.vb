Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Imports System.IO

Imports Melanchall.DryWetMidi.Devices
Imports Melanchall.DryWetMidi.Common
Imports Melanchall.DryWetMidi.Interaction
Imports Melanchall.DryWetMidi.Core

Partial Public Class frmPiano
    Inherits Form
    Public _inputDevice As InputDevice
    Public _outputDevice As OutputDevice
    Public _playback As Playback
    Public _recording As Recording

    Dim a As Short
    '  Public Sub New()
    '     InitializeComponent()
    '  End Sub

    Public Sub frmPiano_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        For Each portname_in In InputDevice.GetAll
            Combo_Input.Items.Add(portname_in)
        Next

        For Each portname_out In OutputDevice.GetAll
            Combo_output.Items.Add(portname_out)
        Next

        Combo_Input.SelectedIndex = 0
        Combo_output.SelectedIndex = 3

        _inputDevice = CType(Combo_Input.SelectedItem, InputDevice)
        _outputDevice = CType(Combo_output.SelectedItem, OutputDevice)
        Spin_Channel.SelectedIndex = 15
    End Sub
    Public Sub Combo_Input_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Combo_Input.SelectedIndexChanged
        _inputDevice = CType(Combo_Input.SelectedItem, InputDevice)
    End Sub

    Public Sub Combo_output_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Combo_output.SelectedIndexChanged
        _outputDevice = CType(Combo_output.SelectedItem, OutputDevice)
    End Sub

    Private Sub pKey_MouseDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.MouseEventArgs) Handles pKey.MouseDown
        ' Dim Button As Short = eventArgs.Button \ &H100000
        ' Dim Shift As Short = System.Windows.Forms.Control.ModifierKeys \ &H10000
        Dim Index As Short = pKey.GetIndex(eventSender)
        domusic(Index)
    End Sub

    Private Sub pKey_MouseUp(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.MouseEventArgs) Handles pKey.MouseUp
        ' Dim Button As Short = eventArgs.Button \ &H100000
        ' Dim Shift As Short = System.Windows.Forms.Control.ModifierKeys \ &H10000
        Dim Index As Short = pKey.GetIndex(eventSender)
        domusicstop(Index)
    End Sub
    Public Sub domusic(ByRef mNote As SevenBitNumber)
        Dim Volume As Integer
        Volume = 120
        _outputDevice.SendEvent(New NoteOnEvent(mNote, CType(Volume, SevenBitNumber)) With {.Channel = CType(Spin_Channel.Text - 1, FourBitNumber)})
        pKey(mNote).BackColor = System.Drawing.Color.Red
    End Sub
    Public Sub domusicstop(ByRef mNote As SevenBitNumber)
        _outputDevice.SendEvent(New NoteOffEvent(mNote, CType(0, SevenBitNumber)) With {.Channel = CType(Spin_Channel.Text - 1, FourBitNumber)})

        If pKey(mNote).Tag = "1" Then
            pKey(mNote).BackColor = System.Drawing.Color.White
        Else
            pKey(mNote).BackColor = System.Drawing.Color.Black
        End If
    End Sub

    Private Sub List1_MouseDown(sender As Object, e As MouseEventArgs) Handles List1.MouseDown
        If (e.Button = MouseButtons.Left) Then
            Exit Sub
        End If

        List1.SelectedIndex = List1.IndexFromPoint(e.X, e.Y)

        If List1.SelectedItem Is Nothing Then
            Exit Sub
        End If

        RECOGNIZE_ON()
    End Sub

    Private Sub List1_MouseUp(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.MouseEventArgs) Handles List1.MouseUp
        STOPLISTBOX()
    End Sub
    Private Sub Cmd_Play_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Cmd_Play.Click
        Dim tempo As Single

        tempo = Val(Text1.Text)
        If (tempo < 20 Or tempo > 400) Then 'Tempo out of range
            Text1.Text = " "
            MsgBox("Tempo out of range - (Pick between 20 and 400)")
            Exit Sub
        End If

        Timer1.Interval = 60 * (1000 / tempo) '  Timer for squares
        Timer1.Enabled = True

    End Sub
    Private Sub CMD_Stop_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Cmd_Stop.Click
        STOPLISTBOX()
        Timer1.Enabled = False

        _Shape_1.BackColor = Color.White
        _Shape_2.BackColor = Color.White
        _Shape_3.BackColor = Color.White
        _Shape_4.BackColor = Color.White
        a = 0
    End Sub

    Public Sub STOPLISTBOX()
        Dim X As Integer
        For X = 1 To 71 '(stop all notes)
            domusicstop(X)
        Next X

    End Sub

    Private Sub timer1_Tick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Timer1.Tick

        If a = 4 Or List1.SelectedIndex = -1 Then
            a = 0
            List1.SetSelected((List1.SelectedIndex + 1) Mod List1.Items.Count, True)

        End If

        a = a + 1
        If a = 1 Then
            STOPLISTBOX()
            RECOGNIZE_ON()

            _Shape_4.BackColor = Color.White
            _Shape_1.BackColor = Color.Turquoise
        ElseIf a = 2 Then
            _Shape_1.BackColor = Color.White
            _Shape_2.BackColor = Color.Turquoise
        ElseIf a = 3 Then
            _Shape_2.BackColor = Color.White
            _Shape_3.BackColor = Color.Turquoise
        ElseIf a = 4 Then
            _Shape_3.BackColor = Color.White
            _Shape_4.BackColor = Color.Turquoise

        End If

    End Sub
    Public Sub RECOGNIZE_ON()
        Dim Value As String
        Dim strSubstr As String
        Dim Slashvalue As String


        If List1.SelectedItem Is Nothing Then
            Exit Sub
        End If
        Value = List1.SelectedItem.ToString()

        If Value.StartsWith("") Then
            ' Button6.PerformClick()
        End If

        If Value.StartsWith("C/") Then
            strSubstr = Mid$(Value, 3, 11)
            Slashvalue = Trim(strSubstr & "")
            '  OptionValue1.Checked = True ' no la pulsa....genial

            If Slashvalue.StartsWith("C") AndAlso Slashvalue.StartsWith("C#") = False Then  ' es como decir-----pero quita el caracter # ...ignora el caracter #..
                Module1.playChordS(24)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("C#") Then
                Module1.playChordS(25)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("D") AndAlso Slashvalue.StartsWith("D#") = False Then
                Module1.playChordS(26)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("D#") Then
                Module1.playChordS(27)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("E") Then
                Module1.playChordS(28)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("F") AndAlso Slashvalue.StartsWith("F#") = False Then
                Module1.playChordS(29)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("F#") Then
                Module1.playChordS(30)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("G") AndAlso Slashvalue.StartsWith("G#") = False Then
                Module1.playChordS(31)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("G#") Then
                Module1.playChordS(32)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("A") AndAlso Slashvalue.StartsWith("A#") = False Then
                Module1.playChordS(33)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("A#") Then
                Module1.playChordS(34)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("B") Then
                Module1.playChordS(35)
                Module1.playChordS(Slashvalue)
            End If
        End If


        If Value.StartsWith("C#/") Then
            strSubstr = Mid$(Value, 4, 11)
            Slashvalue = Trim(strSubstr & "")
            '  OptionValue2.Checked = True

            If Slashvalue.StartsWith("C") AndAlso Slashvalue.StartsWith("C#") = False Then
                Module1.playChordS(25)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("C#") Then
                Module1.playChordS(26)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("D") AndAlso Slashvalue.StartsWith("D#") = False Then
                Module1.playChordS(27)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("D#") Then
                Module1.playChordS(28)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("E") Then
                Module1.playChordS(29)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("F") AndAlso Slashvalue.StartsWith("F#") = False Then
                Module1.playChordS(30)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("F#") Then
                Module1.playChordS(31)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("G") AndAlso Slashvalue.StartsWith("G#") = False Then
                Module1.playChordS(32)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("G#") Then
                Module1.playChordS(33)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("A") AndAlso Slashvalue.StartsWith("A#") = False Then
                Module1.playChordS(34)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("A#") Then
                Module1.playChordS(35)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("B") Then
                Module1.playChordS(36)
                Module1.playChordS(Slashvalue)
            End If
        End If

        If Value.StartsWith("D/") Then
            strSubstr = Mid$(Value, 3, 11)
            Slashvalue = Trim(strSubstr & "")
            '  OptionValue3.Checked = True

            If Slashvalue.StartsWith("C") AndAlso Slashvalue.StartsWith("C#") = False Then
                Module1.playChordS(26)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("C#") Then
                Module1.playChordS(27)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("D") AndAlso Slashvalue.StartsWith("D#") = False Then
                Module1.playChordS(28)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("D#") Then
                Module1.playChordS(29)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("E") Then
                Module1.playChordS(30)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("F") AndAlso Slashvalue.StartsWith("F#") = False Then
                Module1.playChordS(31)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("F#") Then
                Module1.playChordS(32)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("G") AndAlso Slashvalue.StartsWith("G#") = False Then
                Module1.playChordS(33)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("G#") Then
                Module1.playChordS(34)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("A") AndAlso Slashvalue.StartsWith("A#") = False Then
                Module1.playChordS(35)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("A#") Then
                Module1.playChordS(36)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("B") Then
                Module1.playChordS(37)
                Module1.playChordS(Slashvalue)
            End If
        End If

        If Value.StartsWith("D#/") Then
            strSubstr = Mid$(Value, 4, 11)
            Slashvalue = Trim(strSubstr & "")
            '   OptionValue4.Checked = True

            If Slashvalue.StartsWith("C") AndAlso Slashvalue.StartsWith("C#") = False Then
                Module1.playChordS(27)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("C#") Then
                Module1.playChordS(28)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("D") AndAlso Slashvalue.StartsWith("D#") = False Then
                Module1.playChordS(29)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("D#") Then
                Module1.playChordS(30)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("E") Then
                Module1.playChordS(31)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("F") AndAlso Slashvalue.StartsWith("F#") = False Then
                Module1.playChordS(32)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("F#") Then
                Module1.playChordS(33)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("G") AndAlso Slashvalue.StartsWith("G#") = False Then
                Module1.playChordS(34)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("G#") Then
                Module1.playChordS(35)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("A") AndAlso Slashvalue.StartsWith("A#") = False Then
                Module1.playChordS(36)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("A#") Then
                Module1.playChordS(37)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("B") Then
                Module1.playChordS(38)
                Module1.playChordS(Slashvalue)
            End If
        End If

        If Value.StartsWith("E/") Then
            strSubstr = Mid$(Value, 3, 11)
            Slashvalue = Trim(strSubstr & "")
            '  OptionValue5.Checked = True

            If Slashvalue.StartsWith("C") AndAlso Slashvalue.StartsWith("C#") = False Then
                Module1.playChordS(28)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("C#") Then
                Module1.playChordS(29)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("D") AndAlso Slashvalue.StartsWith("D#") = False Then
                Module1.playChordS(30)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("D#") Then
                Module1.playChordS(31)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("E") Then
                Module1.playChordS(32)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("F") AndAlso Slashvalue.StartsWith("F#") = False Then
                Module1.playChordS(33)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("F#") Then
                Module1.playChordS(34)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("G") AndAlso Slashvalue.StartsWith("G#") = False Then
                Module1.playChordS(35)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("G#") Then
                Module1.playChordS(36)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("A") AndAlso Slashvalue.StartsWith("A#") = False Then
                Module1.playChordS(37)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("A#") Then
                Module1.playChordS(38)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("B") Then
                Module1.playChordS(39)
                Module1.playChordS(Slashvalue)
            End If
        End If

        If Value.StartsWith("F/") Then
            strSubstr = Mid$(Value, 3, 11)
            Slashvalue = Trim(strSubstr & "")
            '  OptionValue6.Checked = True

            If Slashvalue.StartsWith("C") AndAlso Slashvalue.StartsWith("C#") = False Then
                Module1.playChordS(29)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("C#") Then
                Module1.playChordS(30)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("D") AndAlso Slashvalue.StartsWith("D#") = False Then
                Module1.playChordS(31)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("D#") Then
                Module1.playChordS(32)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("E") Then
                Module1.playChordS(33)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("F") AndAlso Slashvalue.StartsWith("F#") = False Then
                Module1.playChordS(34)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("F#") Then
                Module1.playChordS(35)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("G") AndAlso Slashvalue.StartsWith("G#") = False Then
                Module1.playChordS(36)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("G#") Then
                Module1.playChordS(37)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("A") AndAlso Slashvalue.StartsWith("A#") = False Then
                Module1.playChordS(38)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("A#") Then
                Module1.playChordS(39)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("B") Then
                Module1.playChordS(40)
                Module1.playChordS(Slashvalue)
            End If
        End If


        If Value.StartsWith("F#/") Then
            strSubstr = Mid$(Value, 4, 11)
            Slashvalue = Trim(strSubstr & "")
            '   OptionValue7.Checked = True

            If Slashvalue.StartsWith("C") AndAlso Slashvalue.StartsWith("C#") = False Then
                Module1.playChordS(30)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("C#") Then
                Module1.playChordS(31)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("D") AndAlso Slashvalue.StartsWith("D#") = False Then
                Module1.playChordS(32)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("D#") Then
                Module1.playChordS(33)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("E") Then
                Module1.playChordS(34)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("F") AndAlso Slashvalue.StartsWith("F#") = False Then
                Module1.playChordS(35)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("F#") Then
                Module1.playChordS(36)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("G") AndAlso Slashvalue.StartsWith("G#") = False Then
                Module1.playChordS(37)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("G#") Then
                Module1.playChordS(38)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("A") AndAlso Slashvalue.StartsWith("A#") = False Then
                Module1.playChordS(39)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("A#") Then
                Module1.playChordS(40)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("B") Then
                Module1.playChordS(41)
                Module1.playChordS(Slashvalue)
            End If
        End If

        If Value.StartsWith("G/") Then
            strSubstr = Mid$(Value, 3, 11)
            Slashvalue = Trim(strSubstr & "")
            '   OptionValue8.Checked = True

            If Slashvalue.StartsWith("C") AndAlso Slashvalue.StartsWith("C#") = False Then
                Module1.playChordS(31)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("C#") Then
                Module1.playChordS(32)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("D") AndAlso Slashvalue.StartsWith("D#") = False Then
                Module1.playChordS(33)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("D#") Then
                Module1.playChordS(34)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("E") Then
                Module1.playChordS(35)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("F") AndAlso Slashvalue.StartsWith("F#") = False Then
                Module1.playChordS(36)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("F#") Then
                Module1.playChordS(37)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("G") AndAlso Slashvalue.StartsWith("G#") = False Then
                Module1.playChordS(38)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("G#") Then
                Module1.playChordS(39)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("A") AndAlso Slashvalue.StartsWith("A#") = False Then
                Module1.playChordS(40)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("A#") Then
                Module1.playChordS(41)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("B") Then
                Module1.playChordS(42)
                Module1.playChordS(Slashvalue)
            End If
        End If

        If Value.StartsWith("G#/") Then
            strSubstr = Mid$(Value, 4, 11)
            Slashvalue = Trim(strSubstr & "")
            '   OptionValue9.Checked = True

            If Slashvalue.StartsWith("C") AndAlso Slashvalue.StartsWith("C#") = False Then
                Module1.playChordS(32)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("C#") Then
                Module1.playChordS(33)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("D") AndAlso Slashvalue.StartsWith("D#") = False Then
                Module1.playChordS(34)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("D#") Then
                Module1.playChordS(35)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("E") Then
                Module1.playChordS(36)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("F") AndAlso Slashvalue.StartsWith("F#") = False Then
                Module1.playChordS(37)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("F#") Then
                Module1.playChordS(38)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("G") AndAlso Slashvalue.StartsWith("G#") = False Then
                Module1.playChordS(39)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("G#") Then
                Module1.playChordS(40)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("A") AndAlso Slashvalue.StartsWith("A#") = False Then
                Module1.playChordS(41)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("A#") Then
                Module1.playChordS(42)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("B") Then
                Module1.playChordS(43)
                Module1.playChordS(Slashvalue)
            End If
        End If

        If Value.StartsWith("A/") Then
            strSubstr = Mid$(Value, 3, 11)
            Slashvalue = Trim(strSubstr & "")
            '  OptionValue10.Checked = True

            If Slashvalue.StartsWith("C") AndAlso Slashvalue.StartsWith("C#") = False Then
                Module1.playChordS(33)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("C#") Then
                Module1.playChordS(34)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("D") AndAlso Slashvalue.StartsWith("D#") = False Then
                Module1.playChordS(35)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("D#") Then
                Module1.playChordS(36)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("E") Then
                Module1.playChordS(37)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("F") AndAlso Slashvalue.StartsWith("F#") = False Then
                Module1.playChordS(38)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("F#") Then
                Module1.playChordS(39)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("G") AndAlso Slashvalue.StartsWith("G#") = False Then
                Module1.playChordS(40)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("G#") Then
                Module1.playChordS(41)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("A") AndAlso Slashvalue.StartsWith("A#") = False Then
                Module1.playChordS(42)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("A#") Then
                Module1.playChordS(43)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("B") Then
                Module1.playChordS(44)
                Module1.playChordS(Slashvalue)
            End If
        End If

        If Value.StartsWith("A#/") Then
            strSubstr = Mid$(Value, 4, 11)
            Slashvalue = Trim(strSubstr & "")
            '  OptionValue11.Checked = True

            If Slashvalue.StartsWith("C") AndAlso Slashvalue.StartsWith("C#") = False Then
                Module1.playChordS(34)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("C#") Then
                Module1.playChordS(35)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("D") AndAlso Slashvalue.StartsWith("D#") = False Then
                Module1.playChordS(36)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("D#") Then
                Module1.playChordS(37)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("E") Then
                Module1.playChordS(38)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("F") AndAlso Slashvalue.StartsWith("F#") = False Then
                Module1.playChordS(39)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("F#") Then
                Module1.playChordS(40)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("G") AndAlso Slashvalue.StartsWith("G#") = False Then
                Module1.playChordS(41)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("G#") Then
                Module1.playChordS(42)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("A") AndAlso Slashvalue.StartsWith("A#") = False Then
                Module1.playChordS(43)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("A#") Then
                Module1.playChordS(44)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("B") Then
                Module1.playChordS(45)
                Module1.playChordS(Slashvalue)
            End If
        End If

        If Value.StartsWith("B/") Then
            strSubstr = Mid$(Value, 3, 11)
            Slashvalue = Trim(strSubstr & "")
            '   OptionValue12.Checked = True

            If Slashvalue.StartsWith("C") AndAlso Slashvalue.StartsWith("C#") = False Then
                Module1.playChordS(35)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("C#") Then
                Module1.playChordS(36)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("D") AndAlso Slashvalue.StartsWith("D#") = False Then
                Module1.playChordS(37)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("D#") Then
                Module1.playChordS(38)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("E") Then
                Module1.playChordS(39)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("F") AndAlso Slashvalue.StartsWith("F#") = False Then
                Module1.playChordS(40)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("F#") Then
                Module1.playChordS(41)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("G") AndAlso Slashvalue.StartsWith("G#") = False Then
                Module1.playChordS(42)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("G#") Then
                Module1.playChordS(43)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("A") AndAlso Slashvalue.StartsWith("A#") = False Then
                Module1.playChordS(44)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("A#") Then
                Module1.playChordS(45)
                Module1.playChordS(Slashvalue)
            End If
            If Slashvalue.StartsWith("B") Then
                Module1.playChordS(46)
                Module1.playChordS(Slashvalue)
            End If
        End If
        playChordS(Value)

    End Sub

    Public Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        If Text_Title.Text = Nothing Then
            MessageBox.Show("Empty Title,.... put a title to your work")
        Else
            _recording = New Recording(TempoMap.Default, _inputDevice)
            _inputDevice.StartEventsListening()
            _recording.Start()
            Button6.BackColor = Color.Red
            Button6.ForeColor = Color.White
            Button6.Text = "Recording......"
        End If
    End Sub

    Public Sub Button7_Click(ByVal sender As Object, e As EventArgs) Handles Button7.Click
        If _recording Is Nothing Then
            Return
        End If
        _recording.Stop()
        Dim midiFile = _recording.ToFile()
        midiFile.Write(Text_Title.Text & ".mid", True, MidiFileFormat.SingleTrack)
        Button6.BackColor = Color.PowderBlue
        Button6.ForeColor = Color.Black
        Button6.Text = "Record"
    End Sub
    Public Sub Button1_Click(ByVal sender As Object, e As EventArgs) Handles Button1.Click
        button3.PerformClick()
        Dim midiFile = Melanchall.DryWetMidi.Core.MidiFile.Read("sample1.mid")
        _playback = midiFile.GetPlayback(_outputDevice)
        _playback.Loop = (True)
        _playback.Start()
    End Sub

    Public Sub button2_Click(ByVal sender As Object, ByVal e As EventArgs) Handles button2.Click
        button3.PerformClick()
        Dim midiFile = Melanchall.DryWetMidi.Core.MidiFile.Read("sample2.mid")
        _playback = midiFile.GetPlayback(_outputDevice)
        _playback.Loop = (True)
        _playback.Start()
    End Sub
    Public Sub button3_Click(ByVal sender As Object, ByVal e As EventArgs) Handles button3.Click

        If _playback Is Nothing Then Return
        _playback.InterruptNotesOnStop = True  ' P E R F E C T  STOP !
        _playback.Stop()

    End Sub

    Public Sub frmPiano_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        ' _playback.Dispose()
        ' _inputDevice.Dispose()
        ' _outputDevice.Dispose()
    End Sub
End Class