Option Strict Off
Option Explicit On
Module Module1
	Public Function playChordS(ByRef ChordName As String) As String
		'Dim n As Short

		Select Case ChordName


            Case "0"
                    frmPiano.domusic(0) : Case "1" : frmPiano.domusic(1) : Case "2" : frmPiano.domusic(2) : Case "3" : frmPiano.domusic(3) : Case "4" : frmPiano.domusic(4) : Case "5" : frmPiano.domusic(5) : Case "6" : frmPiano.domusic(6) : Case "7" : frmPiano.domusic(7) : Case "8" : frmPiano.domusic(8) : Case "9" : frmPiano.domusic(9) : Case "10" : frmPiano.domusic(10) : Case "11" : frmPiano.domusic(11)
                Case "12"
                    frmPiano.domusic(12) : Case "13" : frmPiano.domusic(13) : Case "14" : frmPiano.domusic(14) : Case "15" : frmPiano.domusic(15) : Case "16" : frmPiano.domusic(16) : Case "17" : frmPiano.domusic(17) : Case "18" : frmPiano.domusic(18) : Case "19" : frmPiano.domusic(19) : Case "20" : frmPiano.domusic(20) : Case "21" : frmPiano.domusic(21) : Case "22" : frmPiano.domusic(22) : Case "23" : frmPiano.domusic(23)
                Case "24"
                    frmPiano.domusic(24) : Case "25" : frmPiano.domusic(25) : Case "26" : frmPiano.domusic(26) : Case "27" : frmPiano.domusic(27) : Case "28" : frmPiano.domusic(28) : Case "29" : frmPiano.domusic(29) : Case "30" : frmPiano.domusic(30) : Case "31" : frmPiano.domusic(31) : Case "32" : frmPiano.domusic(32) : Case "33" : frmPiano.domusic(33) : Case "34" : frmPiano.domusic(34) : Case "35" : frmPiano.domusic(35)
                Case "36"
                    frmPiano.domusic(36) : Case "37" : frmPiano.domusic(37) : Case "38" : frmPiano.domusic(38) : Case "39" : frmPiano.domusic(39) : Case "40" : frmPiano.domusic(40) : Case "41" : frmPiano.domusic(41) : Case "42" : frmPiano.domusic(42) : Case "43" : frmPiano.domusic(43) : Case "44" : frmPiano.domusic(44) : Case "45" : frmPiano.domusic(45) : Case "46" : frmPiano.domusic(46)


                Case "CMaj"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43)
                Case "C#Maj"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44)
                Case "DMaj"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45)
                Case "D#Maj"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46)
                Case "EMaj"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47)
                Case "FMaj"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48)
                Case "F#Maj"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49)
                Case "GMaj"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50)
                Case "G#Maj"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51)
                Case "AMaj"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52)
                Case "A#Maj"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53)
                Case "BMaj"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54)

                                                          '--------------------------------------------
                Case "CMaj 7"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(47)
                Case "C#Maj 7"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(48)
                Case "DMaj 7"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(49)
                Case "D#Maj 7"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50)
                Case "EMaj 7"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51)
                Case "FMaj 7"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52)
                Case "F#Maj 7"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53)
                Case "GMaj 7"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54)
                Case "G#Maj 7"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(55)
                Case "AMaj 7"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(56)
                Case "A#Maj 7"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(57)
                Case "BMaj 7"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(58)

                                                      '--------------------------------------------                      
                Case "CMaj 9"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50)
                Case "C#Maj 9"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51)
                Case "DMaj 9"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52)
                Case "D#Maj 9"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53)
                Case "EMaj 9"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54)
                Case "FMaj 9"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(55)
                Case "F#Maj 9"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(56)
                Case "GMaj 9"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(57)
                Case "G#Maj 9"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(55) : frmPiano.domusic(58)
                Case "AMaj 9"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(56) : frmPiano.domusic(59)
                Case "A#Maj 9"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(57) : frmPiano.domusic(60)
                Case "BMaj 9"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(58) : frmPiano.domusic(61)

                                                    '--------------------------------------------
                Case "CMaj 11"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(53)
                Case "C#Maj 11"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(54)
                Case "DMaj 11"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(55)
                Case "D#Maj 11"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(56)
                Case "EMaj 11"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(57)
                Case "FMaj 11"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(55) : frmPiano.domusic(58)
                Case "F#Maj 11"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(56) : frmPiano.domusic(59)
                Case "GMaj 11"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(57) : frmPiano.domusic(60)
                Case "G#Maj 11"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(55) : frmPiano.domusic(58) : frmPiano.domusic(61)
                Case "AMaj 11"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(56) : frmPiano.domusic(59) : frmPiano.domusic(62)
                Case "A#Maj 11"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(57) : frmPiano.domusic(60) : frmPiano.domusic(63)
                Case "BMaj 11"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(58) : frmPiano.domusic(61) : frmPiano.domusic(64)

                                                    '--------------------------------------------
                Case "CMaj 13"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(57)

                Case "C#Maj 13"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(58)

                Case "DMaj 13"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(55) : frmPiano.domusic(59)

                Case "D#Maj 13"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(56) : frmPiano.domusic(60)

                Case "EMaj 13"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(57) : frmPiano.domusic(61)

                Case "FMaj 13"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(55) : frmPiano.domusic(58) : frmPiano.domusic(62)

                Case "F#Maj 13"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(56) : frmPiano.domusic(59) : frmPiano.domusic(63)

                Case "GMaj 13"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(57) : frmPiano.domusic(60) : frmPiano.domusic(64)

                Case "G#Maj 13"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(55) : frmPiano.domusic(58) : frmPiano.domusic(61) : frmPiano.domusic(65)

                Case "AMaj 13"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(56) : frmPiano.domusic(59) : frmPiano.domusic(62) : frmPiano.domusic(66)

                Case "A#Maj 13"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(57) : frmPiano.domusic(60) : frmPiano.domusic(63) : frmPiano.domusic(67)

                Case "BMaj 13"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(58) : frmPiano.domusic(61) : frmPiano.domusic(64) : frmPiano.domusic(68)

                                                          '---------------------------------------------------
                Case "CMaj 7 b5"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(42) : frmPiano.domusic(47)
                Case "C#Maj 7 b5"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(43) : frmPiano.domusic(48)
                Case "DMaj 7 b5"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(44) : frmPiano.domusic(49)
                Case "D#Maj 7 b5"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(50)
                Case "EMaj 7 b5"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(51)
                Case "FMaj 7 b5"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(52)
                Case "F#Maj 7 b5"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(53)
                Case "GMaj 7 b5"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(54)
                Case "G#Maj 7 b5"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(55)
                Case "AMaj 7 b5"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(56)
                Case "A#Maj 7 b5"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(52) : frmPiano.domusic(57)
                Case "BMaj 7 b5"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(53) : frmPiano.domusic(58)

                                               '----------------------------------------------
                Case "CMaj 7 #5"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47)

                Case "C#Maj 7 #5"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48)

                Case "DMaj 7 #5"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49)

                Case "D#Maj 7 #5"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50)

                Case "EMaj 7 #5"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51)

                Case "FMaj 7 #5"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52)

                Case "F#Maj 7 #5"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53)

                Case "GMaj 7 #5"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54)

                Case "G#Maj 7 #5"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(55)

                Case "AMaj 7 #5"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(56)

                Case "A#Maj 7 #5"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(57)

                Case "BMaj 7 #5"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(55) : frmPiano.domusic(58)
                                                '------------------------------------------                  

                Case "CMaj 7 b9"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(49)

                Case "C#Maj 7 b9"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(50)

                Case "DMaj 7 b9"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(51)

                Case "D#Maj 7 b9"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(52)

                Case "EMaj 7 b9"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(53)

                Case "FMaj 7 b9"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(54)

                Case "F#Maj 7 b9"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(55)

                Case "GMaj 7 b9"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(56)

                Case "G#Maj 7 b9"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(55) : frmPiano.domusic(57)

                Case "AMaj 7 b9"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(56) : frmPiano.domusic(58)

                Case "A#Maj 7 b9"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(57) : frmPiano.domusic(59)

                Case "BMaj 7 b9"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(58) : frmPiano.domusic(60)

                                               '---------------------------------
                Case "CMaj 7 #9"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(51)

                Case "C#Maj 7 #9"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(52)

                Case "DMaj 7 #9"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(53)

                Case "D#Maj 7 #9"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(54)

                Case "EMaj 7 #9"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(55)

                Case "FMaj 7 #9"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(56)

                Case "F#Maj 7 #9"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(57)

                Case "GMaj 7 #9"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(58)

                Case "G#Maj 7 #9"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(55) : frmPiano.domusic(59)

                Case "AMaj 7 #9"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(56) : frmPiano.domusic(60)

                Case "A#Maj 7 #9"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(57) : frmPiano.domusic(61)

                Case "BMaj 7 #9"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(58) : frmPiano.domusic(62)

                                                '----------------------------------------
                Case "CMaj 7sus2"
                    frmPiano.domusic(36) : frmPiano.domusic(38) : frmPiano.domusic(43) : frmPiano.domusic(47)

                Case "C#Maj 7sus2"
                    frmPiano.domusic(37) : frmPiano.domusic(39) : frmPiano.domusic(44) : frmPiano.domusic(48)

                Case "DMaj 7sus2"
                    frmPiano.domusic(38) : frmPiano.domusic(40) : frmPiano.domusic(45) : frmPiano.domusic(49)

                Case "D#Maj 7sus2"
                    frmPiano.domusic(39) : frmPiano.domusic(41) : frmPiano.domusic(46) : frmPiano.domusic(50)

                Case "EMaj 7sus2"
                    frmPiano.domusic(40) : frmPiano.domusic(42) : frmPiano.domusic(47) : frmPiano.domusic(51)

                Case "FMaj 7sus2"
                    frmPiano.domusic(41) : frmPiano.domusic(43) : frmPiano.domusic(48) : frmPiano.domusic(52)

                Case "F#Maj 7sus2"
                    frmPiano.domusic(42) : frmPiano.domusic(44) : frmPiano.domusic(49) : frmPiano.domusic(53)

                Case "GMaj 7sus2"
                    frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(50) : frmPiano.domusic(54)

                Case "G#Maj 7sus2"
                    frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(51) : frmPiano.domusic(55)

                Case "AMaj 7sus2"
                    frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(52) : frmPiano.domusic(56)

                Case "A#Maj 7sus2"
                    frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(53) : frmPiano.domusic(57)

                Case "BMaj 7sus2"
                    frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(54) : frmPiano.domusic(58)
                                                            '-------------------------------------------------
                Case "CMaj 7sus4"
                    frmPiano.domusic(36) : frmPiano.domusic(41) : frmPiano.domusic(43) : frmPiano.domusic(47)

                Case "C#Maj 7sus4"
                    frmPiano.domusic(37) : frmPiano.domusic(42) : frmPiano.domusic(44) : frmPiano.domusic(48)

                Case "DMaj 7sus4"
                    frmPiano.domusic(38) : frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(49)

                Case "D#Maj 7sus4"
                    frmPiano.domusic(39) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(50)

                Case "EMaj 7sus4"
                    frmPiano.domusic(40) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(51)

                Case "FMaj 7sus4"
                    frmPiano.domusic(41) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(52)

                Case "F#Maj 7sus4"
                    frmPiano.domusic(42) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(53)

                Case "GMaj 7sus4"
                    frmPiano.domusic(43) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(54)

                Case "G#Maj 7sus4"
                    frmPiano.domusic(44) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(55)

                Case "AMaj 7sus4"
                    frmPiano.domusic(45) : frmPiano.domusic(50) : frmPiano.domusic(52) : frmPiano.domusic(56)

                Case "A#Maj 7sus4"
                    frmPiano.domusic(46) : frmPiano.domusic(51) : frmPiano.domusic(53) : frmPiano.domusic(57)

                Case "BMaj 7sus4"
                    frmPiano.domusic(47) : frmPiano.domusic(52) : frmPiano.domusic(54) : frmPiano.domusic(58)
                                               '-------------------------------

                Case "CMaj 9 b5"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(42) : frmPiano.domusic(47) : frmPiano.domusic(50)

                Case "C#Maj 9 b5"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(43) : frmPiano.domusic(48) : frmPiano.domusic(51)

                Case "DMaj 9 b5"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(44) : frmPiano.domusic(49) : frmPiano.domusic(52)

                Case "D#Maj 9 b5"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(50) : frmPiano.domusic(53)

                Case "EMaj 9 b5"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(51) : frmPiano.domusic(54)

                Case "FMaj 9 b5"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(52) : frmPiano.domusic(55)

                Case "F#Maj 9 b5"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(53) : frmPiano.domusic(56)

                Case "GMaj 9 b5"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(54) : frmPiano.domusic(57)

                Case "G#Maj 9 b5"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(55) : frmPiano.domusic(58)

                Case "AMaj 9 b5"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(56) : frmPiano.domusic(59)

                Case "A#Maj 9 b5"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(52) : frmPiano.domusic(57) : frmPiano.domusic(60)

                Case "BMaj 9 b5"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(53) : frmPiano.domusic(58) : frmPiano.domusic(61)
                                                      '------------------------------

                Case "CMaj 7 #11"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(54)

                Case "C#Maj 7 #11"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(55)

                Case "DMaj 7 #11"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(56)

                Case "D#Maj 7 #11"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(57)

                Case "EMaj 7 #11"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(58)

                Case "FMaj 7 #11"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(59)

                Case "F#Maj 7 #11"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(60)

                Case "GMaj 7 #11"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(61)

                Case "G#Maj 7 #11"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(55) : frmPiano.domusic(62)

                Case "AMaj 7 #11"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(56) : frmPiano.domusic(63)

                Case "A#Maj 7 #11"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(57) : frmPiano.domusic(64)

                Case "BMaj 7 #11"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(58) : frmPiano.domusic(65)

                                                   '-------------------------------

                Case "CMaj 9 #11"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54)

                Case "C#Maj 9 #11"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(55)

                Case "DMaj 9 #11"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(56)

                Case "D#Maj 9 #11"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(57)

                Case "EMaj 9 #11"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(58)

                Case "FMaj 9 #11"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(55) : frmPiano.domusic(59)

                Case "F#Maj 9 #11"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(56) : frmPiano.domusic(60)

                Case "GMaj 9 #11"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(57) : frmPiano.domusic(61)

                Case "G#Maj 9 #11"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(55) : frmPiano.domusic(58) : frmPiano.domusic(62)

                Case "AMaj 9 #11"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(56) : frmPiano.domusic(59) : frmPiano.domusic(63)

                Case "A#Maj 9 #11"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(57) : frmPiano.domusic(60) : frmPiano.domusic(64)

                Case "BMaj 9 #11"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(58) : frmPiano.domusic(61) : frmPiano.domusic(65)

                                                           '------------------------------

                Case "CMaj7add11"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(53)

                Case "C#Maj7add11"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(54)

                Case "DMaj7add11"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(55)

                Case "D#Maj7add11"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(56)

                Case "EMaj7add11"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(57)

                Case "FMaj7add11"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(58)

                Case "F#Maj7add11"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(59)

                Case "GMaj7add11"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(60)

                Case "G#Maj7add11"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(55) : frmPiano.domusic(61)

                Case "AMaj7add11"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(56) : frmPiano.domusic(62)

                Case "A#Maj7add11"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(57) : frmPiano.domusic(63)

                Case "BMaj7add11"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(58) : frmPiano.domusic(64)

                                                      '--------------------------------

                Case "CMaj 69"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(50)

                Case "C#Maj 69"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(51)

                Case "DMaj 69"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(52)

                Case "D#Maj 69"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(53)

                Case "EMaj 69"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(54)

                Case "FMaj 69"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(55)

                Case "F#Maj 69"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(56)

                Case "GMaj 69"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(52) : frmPiano.domusic(57)

                Case "G#Maj 69"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(53) : frmPiano.domusic(58)

                Case "AMaj 69"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(54) : frmPiano.domusic(59)

                Case "A#Maj 69"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(55) : frmPiano.domusic(60)

                Case "BMaj 69"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(56) : frmPiano.domusic(61)

                                                    '--------------------------------

                Case "Cmin"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(43)

                Case "C#min"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(44)

                Case "Dmin"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(45)

                Case "D#min"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(46)

                Case "Emin"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(47)

                Case "Fmin"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(48)

                Case "F#min"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(49)

                Case "Gmin"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50)

                Case "G#min"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51)

                Case "Amin"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52)

                Case "A#min"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53)

                Case "Bmin"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54)

                                                    '----------------------------

                Case "Cmin 7"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46)

                Case "C#min 7"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47)

                Case "Dmin 7"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48)

                Case "D#min 7"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49)

                Case "Emin 7"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50)

                Case "Fmin 7"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51)

                Case "F#min 7"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52)

                Case "Gmin 7"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53)

                Case "G#min 7"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54)

                Case "Amin 7"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(55)

                Case "A#min 7"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(56)

                Case "Bmin 7"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(57)
                                       '-----------------------------------
                Case "Cmin 9"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50)

                Case "C#min 9"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51)

                Case "Dmin 9"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52)

                Case "D#min 9"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53)

                Case "Emin 9"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54)

                Case "Fmin 9"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(55)

                Case "F#min 9"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(56)

                Case "Gmin 9"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(57)

                Case "G#min 9"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(58)

                Case "Amin 9"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(55) : frmPiano.domusic(59)

                Case "A#min 9"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(56) : frmPiano.domusic(60)

                Case "Bmin 9"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(57) : frmPiano.domusic(61)
                               '----------------------------------
                Case "Cmin 11"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53)

                Case "C#min 11"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54)

                Case "Dmin 11"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(55)

                Case "D#min 11"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(56)

                Case "Emin 11"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(57)

                Case "Fmin 11"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(55) : frmPiano.domusic(58)

                Case "F#min 11"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(56) : frmPiano.domusic(59)

                Case "Gmin 11"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(57) : frmPiano.domusic(60)

                Case "G#min 11"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(58) : frmPiano.domusic(61)

                Case "Amin 11"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(55) : frmPiano.domusic(59) : frmPiano.domusic(62)

                Case "A#min 11"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(56) : frmPiano.domusic(60) : frmPiano.domusic(63)

                Case "Bmin 11"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(57) : frmPiano.domusic(61) : frmPiano.domusic(64)
                              '------------------------------
                Case "Cmin 13"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(57)

                Case "C#min 13"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(58)

                Case "Dmin 13"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(55) : frmPiano.domusic(59)

                Case "D#min 13"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(56) : frmPiano.domusic(60)

                Case "Emin 13"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(57) : frmPiano.domusic(61)

                Case "Fmin 13"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(55) : frmPiano.domusic(58) : frmPiano.domusic(62)

                Case "F#min 13"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(56) : frmPiano.domusic(59) : frmPiano.domusic(63)

                Case "Gmin 13"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(57) : frmPiano.domusic(60) : frmPiano.domusic(64)

                Case "G#min 13"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(58) : frmPiano.domusic(61) : frmPiano.domusic(65)

                Case "Amin 13"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(55) : frmPiano.domusic(59) : frmPiano.domusic(62) : frmPiano.domusic(66)

                Case "A#min 13"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(56) : frmPiano.domusic(60) : frmPiano.domusic(63) : frmPiano.domusic(67)

                Case "Bmin 13"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(57) : frmPiano.domusic(61) : frmPiano.domusic(64) : frmPiano.domusic(68)
                              '-------------------------------
                Case "Cmin 7 b5"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(46)

                Case "C#min 7 b5"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(47)

                Case "Dmin 7 b5"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(48)

                Case "D#min 7 b5"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(49)

                Case "Emin 7 b5"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50)

                Case "Fmin 7 b5"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51)

                Case "F#min 7 b5"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52)

                Case "Gmin 7 b5"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53)

                Case "G#min 7 b5"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54)

                Case "Amin 7 b5"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(55)

                Case "A#min 7 b5"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(56)

                Case "Bmin 7 b5"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(57)
                              '-------------------------------------
                Case "Cmin 7 #5"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(44) : frmPiano.domusic(46)

                Case "C#min 7 #5"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(45) : frmPiano.domusic(47)

                Case "Dmin 7 #5"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(46) : frmPiano.domusic(48)

                Case "D#min 7 #5"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(47) : frmPiano.domusic(49)

                Case "Emin 7 #5"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(48) : frmPiano.domusic(50)

                Case "Fmin 7 #5"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(49) : frmPiano.domusic(51)

                Case "F#min 7 #5"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(50) : frmPiano.domusic(52)

                Case "Gmin 7 #5"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(51) : frmPiano.domusic(53)

                Case "G#min 7 #5"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(52) : frmPiano.domusic(54)

                Case "Amin 7 #5"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(53) : frmPiano.domusic(55)

                Case "A#min 7 #5"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(54) : frmPiano.domusic(56)

                Case "Bmin 7 #5"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(55) : frmPiano.domusic(57)
                              '---------------------------------
                Case "Cmin 7 #9"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(51)

                Case "C#min 7 #9"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(52)

                Case "Dmin 7 #9"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(53)

                Case "D#min 7 #9"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(54)

                Case "Emin 7 #9"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(55)

                Case "Fmin 7 #9"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(56)

                Case "F#min 7 #9"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(57)

                Case "Gmin 7 #9"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(58)

                Case "G#min 7 #9"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(59)

                Case "Amin 7 #9"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(55) : frmPiano.domusic(60)

                Case "A#min 7 #9"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(56) : frmPiano.domusic(61)

                Case "Bmin 7 #9"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(57) : frmPiano.domusic(62)
                                '-----------------------
                Case "Cmin7add11"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(53)

                Case "C#min7add11"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(54)

                Case "Dmin7add11"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(55)

                Case "D#min7add11"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(56)

                Case "Emin7add11"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(57)

                Case "Fmin7add11"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(58)

                Case "F#min7add11"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(59)

                Case "Gmin7add11"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(60)

                Case "G#min7add11"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(61)

                Case "Amin7add11"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(55) : frmPiano.domusic(62)

                Case "A#min7add11"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(56) : frmPiano.domusic(63)

                Case "Bmin7add11"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(57) : frmPiano.domusic(64)
                              '--------------------------
                Case "Cmin 9 #5"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(50)

                Case "C#min 9 #5"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(51)

                Case "Dmin 9 #5"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(52)

                Case "D#min 9 #5"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(53)

                Case "Emin 9 #5"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(54)

                Case "Fmin 9 #5"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(55)

                Case "F#min 9 #5"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(50) : frmPiano.domusic(52) : frmPiano.domusic(56)

                Case "Gmin 9 #5"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(51) : frmPiano.domusic(53) : frmPiano.domusic(57)

                Case "G#min 9 #5"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(52) : frmPiano.domusic(54) : frmPiano.domusic(58)

                Case "Amin 9 #5"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(53) : frmPiano.domusic(55) : frmPiano.domusic(59)

                Case "A#min 9 #5"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(54) : frmPiano.domusic(56) : frmPiano.domusic(60)

                Case "Bmin 9 #5"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(55) : frmPiano.domusic(57) : frmPiano.domusic(61)
                              '----------------------------
                Case "Cmin 6"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(45)
                Case "C#min 6"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(46)
                Case "Dmin 6"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(47)
                Case "D#min 6"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(48)
                Case "Emin 6"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(49)
                Case "Fmin 6"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(50)
                Case "F#min 6"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(51)
                Case "Gmin 6"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(52)
                Case "G#min 6"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(53)
                Case "Amin 6"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(54)
                Case "A#min 6"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(55)
                Case "Bmin 6"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(56)
                             '---------------------------
                Case "Cmin 69"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(50)
                Case "C#min 69"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(51)
                Case "Dmin 69"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(52)
                Case "D#min 69"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(53)
                Case "Emin 69"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(54)
                Case "Fmin 69"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(55)
                Case "F#min 69"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(56)
                Case "Gmin 69"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(52) : frmPiano.domusic(57)
                Case "G#min 69"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(53) : frmPiano.domusic(58)
                Case "Amin 69"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(54) : frmPiano.domusic(59)
                Case "A#min 69"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(55) : frmPiano.domusic(60)
                Case "Bmin 69"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(56) : frmPiano.domusic(61)
                            '-----------------------
                Case "CminMaj 7"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(47)
                Case "C#minMaj 7"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(48)
                Case "DminMaj 7"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(49)
                Case "D#minMaj 7"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(50)
                Case "EminMaj 7"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(51)
                Case "FminMaj 7"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(52)
                Case "F#minMaj 7"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(53)
                Case "GminMaj 7"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(54)
                Case "G#minMaj 7"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(55)
                Case "AminMaj 7"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(56)
                Case "A#minMaj 7"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(57)
                Case "BminMaj 7"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(58)
                              '--------------------------
                Case "CminMaj 9"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(51)
                Case "C#minMaj 9"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(52)
                Case "DminMaj 9"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(53)
                Case "D#minMaj 9"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(54)
                Case "EminMaj 9"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(55)
                Case "FminMaj 9"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(56)
                Case "F#minMaj 9"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(57)
                Case "GminMaj 9"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(58)
                Case "G#minMaj 9"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(55) : frmPiano.domusic(59)
                Case "AminMaj 9"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(56) : frmPiano.domusic(60)
                Case "A#minMaj 9"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(57) : frmPiano.domusic(61)
                Case "BminMaj 9"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(58) : frmPiano.domusic(62)
                              '--------------------------
                Case "Cmin add4"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(41) : frmPiano.domusic(43)
                Case "C#min add4"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(42) : frmPiano.domusic(44)
                Case "Dmin add4"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(43) : frmPiano.domusic(45)
                Case "D#min add4"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(44) : frmPiano.domusic(46)
                Case "Emin add4"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(47)
                Case "Fmin add4"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(48)
                Case "F#min add4"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(49)
                Case "Gmin add4"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(50)
                Case "G#min add4"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(51)
                Case "Amin add4"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(52)
                Case "A#min add4"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(53)
                Case "Bmin add4"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(52) : frmPiano.domusic(54)
                             '---------------------------
                Case "Cmin add9"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(50)
                Case "C#min add9"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(51)
                Case "Dmin add9"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(52)
                Case "D#min add9"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(53)
                Case "Emin add9"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(54)
                Case "Fmin add9"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(55)
                Case "F#min add9"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(56)
                Case "Gmin add9"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(57)
                Case "G#min add9"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(58)
                Case "Amin add9"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(59)
                Case "A#min add9"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(60)
                Case "Bmin add9"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(61)
                             '------------------------
                Case "Cmin6 add4"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(41) : frmPiano.domusic(43) : frmPiano.domusic(45)
                Case "C#min6 add4"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(42) : frmPiano.domusic(44) : frmPiano.domusic(46)
                Case "Dmin6 add4"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(47)
                Case "D#min6 add4"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(48)
                Case "Emin6 add4"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(49)
                Case "Fmin6 add4"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(50)
                Case "F#min6 add4"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(51)
                Case "Gmin6 add4"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(52)
                Case "G#min6 add4"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(53)
                Case "Amin6 add4"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(52) : frmPiano.domusic(54)
                Case "A#min6 add4"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(53) : frmPiano.domusic(55)
                Case "Bmin6 add4"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(52) : frmPiano.domusic(54) : frmPiano.domusic(56)
                              '------------------------------------------------
                Case "Cmin7 add4"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(41) : frmPiano.domusic(43) : frmPiano.domusic(46)
                Case "C#min7 add4"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(42) : frmPiano.domusic(44) : frmPiano.domusic(47)
                Case "Dmin7 add4"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(48)
                Case "D#min7 add4"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(49)
                Case "Emin7 add4"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(50)
                Case "Fmin7 add4"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(51)
                Case "F#min7 add4"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(52)
                Case "Gmin7 add4"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(53)
                Case "G#min7 add4"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(54)
                Case "Amin7 add4"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(52) : frmPiano.domusic(55)
                Case "A#min7 add4"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(53) : frmPiano.domusic(56)
                Case "Bmin7 add4"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(52) : frmPiano.domusic(54) : frmPiano.domusic(57)
                                            '------------------------------------
                Case "Cmin7 #5#9"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(51)
                Case "C#min7 #5#9"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(52)
                Case "Dmin7 #5#9"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(53)
                Case "D#min7 #5#9"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(54)
                Case "Emin7 #5#9"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(55)
                Case "Fmin7 #5#9"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(56)
                Case "F#min7 #5#9"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(50) : frmPiano.domusic(52) : frmPiano.domusic(57)
                Case "Gmin7 #5#9"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(51) : frmPiano.domusic(53) : frmPiano.domusic(58)
                Case "G#min7 #5#9"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(52) : frmPiano.domusic(54) : frmPiano.domusic(59)
                Case "Amin7 #5#9"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(53) : frmPiano.domusic(55) : frmPiano.domusic(60)
                Case "A#min7 #5#9"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(54) : frmPiano.domusic(56) : frmPiano.domusic(61)
                Case "Bmin7 #5#9"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(55) : frmPiano.domusic(57) : frmPiano.domusic(62)
                               '----------------------------------
                Case "Cmin9 add6"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(50)
                Case "C#min9 add6"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(51)
                Case "Dmin9 add6"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(52)
                Case "D#min9 add6"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(53)
                Case "Emin9 add6"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(54)
                Case "Fmin9 add6"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(55)
                Case "F#min9 add6"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(56)
                Case "Gmin9 add6"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(52) : frmPiano.domusic(57)
                Case "G#min9 add6"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(53) : frmPiano.domusic(58)
                Case "Amin9 add6"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(54) : frmPiano.domusic(59)
                Case "A#min9 add6"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(55) : frmPiano.domusic(60)
                Case "Bmin9 add6"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(56) : frmPiano.domusic(61)
                               '----------------------------------------
                Case "Cmin 11 b5"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53)
                Case "C#min 11 b5"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54)
                Case "Dmin 11 b5"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(55)
                Case "D#min 11 b5"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(56)
                Case "Emin 11 b5"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(57)
                Case "Fmin 11 b5"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(55) : frmPiano.domusic(58)
                Case "F#min 11 b5"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(56) : frmPiano.domusic(59)
                Case "Gmin 11 b5"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(57) : frmPiano.domusic(60)
                Case "G#min 11 b5"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(58) : frmPiano.domusic(61)
                Case "Amin 11 b5"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(55) : frmPiano.domusic(59) : frmPiano.domusic(62)
                Case "A#min 11 b5"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(56) : frmPiano.domusic(60) : frmPiano.domusic(63)
                Case "Bmin 11 b5"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(57) : frmPiano.domusic(61) : frmPiano.domusic(64)
                               '-------------------------------------
                Case "Cmin11#5#9"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(51) : frmPiano.domusic(53)
                Case "C#min11#5#9"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(52) : frmPiano.domusic(54)
                Case "Dmin11#5#9"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(53) : frmPiano.domusic(55)
                Case "D#min11#5#9"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(54) : frmPiano.domusic(56)
                Case "Emin11#5#9"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(55) : frmPiano.domusic(57)
                Case "Fmin11#5#9"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(56) : frmPiano.domusic(58)
                Case "F#min11#5#9"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(50) : frmPiano.domusic(52) : frmPiano.domusic(57) : frmPiano.domusic(59)
                Case "Gmin11#5#9"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(51) : frmPiano.domusic(53) : frmPiano.domusic(58) : frmPiano.domusic(60)
                Case "G#min11#5#9"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(52) : frmPiano.domusic(54) : frmPiano.domusic(59) : frmPiano.domusic(61)
                Case "Amin11#5#9"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(53) : frmPiano.domusic(55) : frmPiano.domusic(60) : frmPiano.domusic(62)
                Case "A#min11#5#9"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(54) : frmPiano.domusic(56) : frmPiano.domusic(61) : frmPiano.domusic(63)
                Case "Bmin11#5#9"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(55) : frmPiano.domusic(57) : frmPiano.domusic(62) : frmPiano.domusic(64)
                               '-------------------------------
                Case "Csus2 sus4"
                    frmPiano.domusic(36) : frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(43)
                Case "C#sus2 sus4"
                    frmPiano.domusic(37) : frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(44)
                Case "Dsus2 sus4"
                    frmPiano.domusic(38) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(45)
                Case "D#sus2 sus4"
                    frmPiano.domusic(39) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(46)
                Case "Esus2 sus4"
                    frmPiano.domusic(40) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(47)
                Case "Fsus2 sus4"
                    frmPiano.domusic(41) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(48)
                Case "F#sus2 sus4"
                    frmPiano.domusic(42) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(49)
                Case "Gsus2 sus4"
                    frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(50)
                Case "G#sus2 sus4"
                    frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(51)
                Case "Asus2 sus4"
                    frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(52)
                Case "A#sus2 sus4"
                    frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(53)
                Case "Bsus2 sus4"
                    frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(54)
                               '------------------------------
                Case "Csus 2"
                    frmPiano.domusic(36) : frmPiano.domusic(38) : frmPiano.domusic(43)
                Case "C#sus 2"
                    frmPiano.domusic(37) : frmPiano.domusic(39) : frmPiano.domusic(44)
                Case "Dsus 2"
                    frmPiano.domusic(38) : frmPiano.domusic(40) : frmPiano.domusic(45)
                Case "D#sus 2"
                    frmPiano.domusic(39) : frmPiano.domusic(41) : frmPiano.domusic(46)
                Case "Esus 2"
                    frmPiano.domusic(40) : frmPiano.domusic(42) : frmPiano.domusic(47)
                Case "Fsus 2"
                    frmPiano.domusic(41) : frmPiano.domusic(43) : frmPiano.domusic(48)
                Case "F#sus 2"
                    frmPiano.domusic(42) : frmPiano.domusic(44) : frmPiano.domusic(49)
                Case "Gsus 2"
                    frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(50)
                Case "G#sus 2"
                    frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(51)
                Case "Asus 2"
                    frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(52)
                Case "A#sus 2"
                    frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(53)
                Case "Bsus 2"
                    frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(54)
                               '--------------------------------
                Case "Csus 4"
                    frmPiano.domusic(36) : frmPiano.domusic(41) : frmPiano.domusic(43)
                Case "C#sus 4"
                    frmPiano.domusic(37) : frmPiano.domusic(42) : frmPiano.domusic(44)
                Case "Dsus 4"
                    frmPiano.domusic(38) : frmPiano.domusic(43) : frmPiano.domusic(45)
                Case "D#sus 4"
                    frmPiano.domusic(39) : frmPiano.domusic(44) : frmPiano.domusic(46)
                Case "Esus 4"
                    frmPiano.domusic(40) : frmPiano.domusic(45) : frmPiano.domusic(47)
                Case "Fsus 4"
                    frmPiano.domusic(41) : frmPiano.domusic(46) : frmPiano.domusic(48)
                Case "F#sus 4"
                    frmPiano.domusic(42) : frmPiano.domusic(47) : frmPiano.domusic(49)
                Case "Gsus 4"
                    frmPiano.domusic(43) : frmPiano.domusic(48) : frmPiano.domusic(50)
                Case "G#sus 4"
                    frmPiano.domusic(44) : frmPiano.domusic(49) : frmPiano.domusic(51)
                Case "Asus 4"
                    frmPiano.domusic(45) : frmPiano.domusic(50) : frmPiano.domusic(52)
                Case "A#sus 4"
                    frmPiano.domusic(46) : frmPiano.domusic(51) : frmPiano.domusic(53)
                Case "Bsus 4"
                    frmPiano.domusic(47) : frmPiano.domusic(52) : frmPiano.domusic(54)
                                '-----------------------
                Case "Cadd 2"
                    frmPiano.domusic(36) : frmPiano.domusic(38) : frmPiano.domusic(40) : frmPiano.domusic(43)
                Case "C#add 2"
                    frmPiano.domusic(37) : frmPiano.domusic(39) : frmPiano.domusic(41) : frmPiano.domusic(44)
                Case "Dadd 2"
                    frmPiano.domusic(38) : frmPiano.domusic(40) : frmPiano.domusic(42) : frmPiano.domusic(45)
                Case "D#add 2"
                    frmPiano.domusic(39) : frmPiano.domusic(41) : frmPiano.domusic(43) : frmPiano.domusic(46)
                Case "Eadd 2"
                    frmPiano.domusic(40) : frmPiano.domusic(42) : frmPiano.domusic(44) : frmPiano.domusic(47)
                Case "Fadd 2"
                    frmPiano.domusic(41) : frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(48)
                Case "F#add 2"
                    frmPiano.domusic(42) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(49)
                Case "Gadd 2"
                    frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(50)
                Case "G#add 2"
                    frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(51)
                Case "Aadd 2"
                    frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(52)
                Case "A#add 2"
                    frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(53)
                Case "Badd 2"
                    frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(54)
                                '-----------------------------------
                Case "Cadd 4"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(41) : frmPiano.domusic(43)
                Case "C#add 4"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(42) : frmPiano.domusic(44)
                Case "Dadd 4"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(43) : frmPiano.domusic(45)
                Case "D#add 4"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(44) : frmPiano.domusic(46)
                Case "Eadd 4"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(45) : frmPiano.domusic(47)
                Case "Fadd 4"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(46) : frmPiano.domusic(48)
                Case "F#add 4"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(47) : frmPiano.domusic(49)
                Case "Gadd 4"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(48) : frmPiano.domusic(50)
                Case "G#add 4"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(49) : frmPiano.domusic(51)
                Case "Aadd 4"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(50) : frmPiano.domusic(52)
                Case "A#add 4"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(51) : frmPiano.domusic(53)
                Case "Badd 4"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(52) : frmPiano.domusic(54)
                               '---------------------------------
                Case "Cadd 9"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(50)
                Case "C#add 9"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(51)
                Case "Dadd 9"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(52)
                Case "D#add 9"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(53)
                Case "Eadd 9"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(54)
                Case "Fadd 9"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(55)
                Case "F#add 9"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(56)
                Case "Gadd 9"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(57)
                Case "G#add 9"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(58)
                Case "Aadd 9"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(59)
                Case "A#add 9"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(60)
                Case "Badd 9"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(61)
                               '------------------------------
                Case "Cdim"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(42)
                Case "C#dim"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(43)
                Case "Ddim"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(44)
                Case "D#dim"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(45)
                Case "Edim"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(46)
                Case "Fdim"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(47)
                Case "F#dim"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(48)
                Case "Gdim"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(49)
                Case "G#dim"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(50)
                Case "Adim"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(51)
                Case "A#dim"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(52)
                Case "Bdim"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(53)
                               '----------------------------------
                Case "Cdim 7"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(45)
                Case "C#dim 7"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(46)
                Case "Ddim 7"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(47)
                Case "D#dim 7"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(48)
                Case "Edim 7"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(49)
                Case "Fdim 7"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(50)
                Case "F#dim 7"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(51)
                Case "Gdim 7"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(52)
                Case "G#dim 7"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(53)
                Case "Adim 7"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(54)
                Case "A#dim 7"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(55)
                Case "Bdim 7"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(56)
                               '--------------------------------
                Case "Cdim add 4"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(41) : frmPiano.domusic(42)
                Case "C#dim add 4"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(42) : frmPiano.domusic(43)
                Case "Ddim add 4"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(43) : frmPiano.domusic(44)
                Case "D#dim add 4"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(44) : frmPiano.domusic(45)
                Case "Edim add 4"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(46)
                Case "Fdim add 4"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(47)
                Case "F#dim add 4"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(48)
                Case "Gdim add 4"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(49)
                Case "G#dim add 4"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(50)
                Case "Adim add 4"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(51)
                Case "A#dim add 4"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(52)
                Case "Bdim add 4"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(52) : frmPiano.domusic(53)
                                '------------------------------
                Case "Cdim-Maj7"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(47)
                Case "C#dim-Maj7"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(48)
                Case "Ddim-Maj7"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(49)
                Case "D#dim-Maj7"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(50)
                Case "Edim-Maj7"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(51)
                Case "Fdim-Maj7"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(52)
                Case "F#dim-Maj7"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(53)
                Case "Gdim-Maj7"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(54)
                Case "G#dim-Maj7"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(55)
                Case "Adim-Maj7"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(56)
                Case "A#dim-Maj7"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(57)
                Case "Bdim-Maj7"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(58)
                              '------------------------------------
                Case "Caug"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(44)
                Case "C#aug"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(45)
                Case "Daug"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(46)
                Case "D#aug"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(47)
                Case "Eaug"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(48)
                Case "Faug"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(49)
                Case "F#aug"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(50)
                Case "Gaug"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(51)
                Case "G#aug"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(52)
                Case "Aaug"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(53)
                Case "A#aug"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(54)
                Case "Baug"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(55)
                               '---------------------------------
                Case "Caug 6"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(45)
                Case "C#aug 6"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(46)
                Case "Daug 6"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(47)
                Case "D#aug 6"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(48)
                Case "Eaug 6"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(49)
                Case "Faug 6"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(50)
                Case "F#aug 6"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(51)
                Case "Gaug 6"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(52)
                Case "G#aug 6"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(53)
                Case "Aaug 6"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(54)
                Case "A#aug 6"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(55)
                Case "Baug 6"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(55) : frmPiano.domusic(56)
                               '-------------------------------
                Case "Caug m11"
                    frmPiano.domusic(36) : frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(54)
                Case "C#aug m11"
                    frmPiano.domusic(37) : frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(55)
                Case "Daug m11"
                    frmPiano.domusic(38) : frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(56)
                Case "D#aug m11"
                    frmPiano.domusic(39) : frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(57)
                Case "Eaug m11"
                    frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(58)
                Case "Faug m11"
                    frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(55) : frmPiano.domusic(59)
                Case "F#aug m11"
                    frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(56) : frmPiano.domusic(60)
                Case "Gaug m11"
                    frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(57) : frmPiano.domusic(61)
                Case "G#aug m11"
                    frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(58) : frmPiano.domusic(62)
                Case "Aaug m11"
                    frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(55) : frmPiano.domusic(59) : frmPiano.domusic(63)
                Case "A#aug m11"
                    frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(56) : frmPiano.domusic(60) : frmPiano.domusic(64)
                Case "Baug m11"
                    frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(57) : frmPiano.domusic(61) : frmPiano.domusic(65)
                              '------------------------------
                Case "Cb9"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(49)
                Case "C#b9"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(50)
                Case "C#9"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(51)
                Case "D#b9"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(52)
                Case "Eb9"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(53)
                Case "Fb9"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(54)
                Case "F#b9"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(55)
                Case "Gb9"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(56)
                Case "G#b9"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(57)
                Case "Ab9"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(55) : frmPiano.domusic(58)
                Case "A#b9"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(56) : frmPiano.domusic(59)
                Case "Bb9"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(57) : frmPiano.domusic(60)
                                         '--------------------------------------------
                Case "Cb9 b5"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49)
                Case "C#b9 b5"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50)
                Case "C#9 b5"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51)
                Case "D#b9 b5"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52)
                Case "Eb9 b5"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53)
                Case "Fb9 b5"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54)
                Case "F#b9 b5"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(55)
                Case "Gb9 b5"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(56)
                Case "G#b9 b5"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(57)
                Case "Ab9 b5"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(55) : frmPiano.domusic(58)
                Case "A#b9 b5"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(52) : frmPiano.domusic(56) : frmPiano.domusic(59)
                Case "Bb9 b5"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(53) : frmPiano.domusic(57) : frmPiano.domusic(60)
                                      '---------------------------------
                Case "C5"
                    frmPiano.domusic(36) : frmPiano.domusic(43)
                Case "C#5"
                    frmPiano.domusic(37) : frmPiano.domusic(44)
                Case "D5"
                    frmPiano.domusic(38) : frmPiano.domusic(45)
                Case "D#5"
                    frmPiano.domusic(39) : frmPiano.domusic(46)
                Case "E5"
                    frmPiano.domusic(40) : frmPiano.domusic(47)
                Case "F5"
                    frmPiano.domusic(41) : frmPiano.domusic(48)
                Case "F#5"
                    frmPiano.domusic(42) : frmPiano.domusic(49)
                Case "G5"
                    frmPiano.domusic(43) : frmPiano.domusic(50)
                Case "G#5"
                    frmPiano.domusic(44) : frmPiano.domusic(51)
                Case "A5"
                    frmPiano.domusic(45) : frmPiano.domusic(52)
                Case "A#5"
                    frmPiano.domusic(46) : frmPiano.domusic(53)
                Case "B5"
                    frmPiano.domusic(47) : frmPiano.domusic(54)
                             '------------------------
                Case "C5 add7"
                    frmPiano.domusic(36) : frmPiano.domusic(43) : frmPiano.domusic(46)
                Case "C#5 add7"
                    frmPiano.domusic(37) : frmPiano.domusic(44) : frmPiano.domusic(47)
                Case "D5 add7"
                    frmPiano.domusic(38) : frmPiano.domusic(45) : frmPiano.domusic(48)
                Case "D#5 add7"
                    frmPiano.domusic(39) : frmPiano.domusic(46) : frmPiano.domusic(49)
                Case "E5 add7"
                    frmPiano.domusic(40) : frmPiano.domusic(47) : frmPiano.domusic(50)
                Case "F5 add7"
                    frmPiano.domusic(41) : frmPiano.domusic(48) : frmPiano.domusic(51)
                Case "F#5 add7"
                    frmPiano.domusic(42) : frmPiano.domusic(49) : frmPiano.domusic(52)
                Case "G5 add7"
                    frmPiano.domusic(43) : frmPiano.domusic(50) : frmPiano.domusic(53)
                Case "G#5 add7"
                    frmPiano.domusic(44) : frmPiano.domusic(51) : frmPiano.domusic(54)
                Case "A5 add7"
                    frmPiano.domusic(45) : frmPiano.domusic(52) : frmPiano.domusic(55)
                Case "A#5 add7"
                    frmPiano.domusic(46) : frmPiano.domusic(53) : frmPiano.domusic(56)
                Case "B5 add7"
                    frmPiano.domusic(47) : frmPiano.domusic(54) : frmPiano.domusic(57)
                                       '----------------------------
                Case "C6"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(45)
                Case "C#6"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(46)
                Case "D6"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(47)
                Case "D#6"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(48)
                Case "E6"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(49)
                Case "F6"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(50)
                Case "F#6"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(51)
                Case "G6"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(52)
                Case "G#6"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(53)
                Case "A6"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(54)
                Case "A#6"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(55)
                Case "B6"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(56)
                               '--------------------------
                Case "C6 add4"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(41) : frmPiano.domusic(43) : frmPiano.domusic(45)
                Case "C#6 add4"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(42) : frmPiano.domusic(44) : frmPiano.domusic(46)
                Case "D6 add4"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(47)
                Case "D#6 add4"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(48)
                Case "E6 add4"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(49)
                Case "F6 add4"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(50)
                Case "F#6 add4"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(51)
                Case "G6 add4"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(52)
                Case "G#6 add4"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(53)
                Case "A6 add4"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(50) : frmPiano.domusic(52) : frmPiano.domusic(54)
                Case "A#6 add4"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(51) : frmPiano.domusic(53) : frmPiano.domusic(55)
                Case "B6 add4"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(52) : frmPiano.domusic(54) : frmPiano.domusic(56)
                                     '---------------------
                Case "C6 add9"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(50)
                Case "C#6 add9"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(51)
                Case "D6 add9"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(52)
                Case "D#6 add9"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(53)
                Case "E6 add9"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(54)
                Case "F6 add9"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(55)
                Case "F#6 add9"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(56)
                Case "G6 add9"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(52) : frmPiano.domusic(57)
                Case "G#6 add9"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(53) : frmPiano.domusic(58)
                Case "A6 add9"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(54) : frmPiano.domusic(59)
                Case "A#6 add9"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(55) : frmPiano.domusic(60)
                Case "B6 add9"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(56) : frmPiano.domusic(61)
                              '----------------------------
                Case "C6 sus"
                    frmPiano.domusic(36) : frmPiano.domusic(43) : frmPiano.domusic(45)
                Case "C#6 sus"
                    frmPiano.domusic(37) : frmPiano.domusic(44) : frmPiano.domusic(46)
                Case "D6 sus"
                    frmPiano.domusic(38) : frmPiano.domusic(45) : frmPiano.domusic(47)
                Case "D#6 sus"
                    frmPiano.domusic(39) : frmPiano.domusic(46) : frmPiano.domusic(48)
                Case "E6 sus"
                    frmPiano.domusic(40) : frmPiano.domusic(47) : frmPiano.domusic(49)
                Case "F6 sus"
                    frmPiano.domusic(41) : frmPiano.domusic(48) : frmPiano.domusic(50)
                Case "F#6 sus"
                    frmPiano.domusic(42) : frmPiano.domusic(49) : frmPiano.domusic(51)
                Case "G6 sus"
                    frmPiano.domusic(43) : frmPiano.domusic(50) : frmPiano.domusic(52)
                Case "G#6 sus"
                    frmPiano.domusic(44) : frmPiano.domusic(51) : frmPiano.domusic(53)
                Case "A6 sus"
                    frmPiano.domusic(45) : frmPiano.domusic(52) : frmPiano.domusic(54)
                Case "A#6 sus"
                    frmPiano.domusic(46) : frmPiano.domusic(53) : frmPiano.domusic(55)
                Case "B6 sus"
                    frmPiano.domusic(47) : frmPiano.domusic(54) : frmPiano.domusic(56)
                            '-------------------
                Case "C6 b5"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(42) : frmPiano.domusic(45)
                Case "C#6 b5"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(43) : frmPiano.domusic(46)
                Case "D6 b5"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(44) : frmPiano.domusic(47)
                Case "D#6 b5"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(48)
                Case "E6 b5"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(49)
                Case "F6 b5"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(50)
                Case "F#6 b5"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(51)
                Case "G6 b5"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(52)
                Case "G#6 b5"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(53)
                Case "A6 b5"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(54)
                Case "A#6 b5"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(52) : frmPiano.domusic(55)
                Case "B6 b5"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(53) : frmPiano.domusic(56)
                            '--------------------
                Case "C7 sus"
                    frmPiano.domusic(36) : frmPiano.domusic(43) : frmPiano.domusic(46)
                Case "C#7 sus"
                    frmPiano.domusic(37) : frmPiano.domusic(44) : frmPiano.domusic(47)
                Case "D7 sus"
                    frmPiano.domusic(38) : frmPiano.domusic(45) : frmPiano.domusic(48)
                Case "D#7 sus"
                    frmPiano.domusic(39) : frmPiano.domusic(46) : frmPiano.domusic(49)
                Case "E7 sus"
                    frmPiano.domusic(40) : frmPiano.domusic(47) : frmPiano.domusic(50)
                Case "F7 sus"
                    frmPiano.domusic(41) : frmPiano.domusic(48) : frmPiano.domusic(51)
                Case "F#7 sus"
                    frmPiano.domusic(42) : frmPiano.domusic(49) : frmPiano.domusic(52)
                Case "G7 sus"
                    frmPiano.domusic(43) : frmPiano.domusic(50) : frmPiano.domusic(53)
                Case "G#7 sus"
                    frmPiano.domusic(44) : frmPiano.domusic(51) : frmPiano.domusic(54)
                Case "A7 sus"
                    frmPiano.domusic(45) : frmPiano.domusic(52) : frmPiano.domusic(55)
                Case "A#7 sus"
                    frmPiano.domusic(46) : frmPiano.domusic(53) : frmPiano.domusic(56)
                Case "B7 sus"
                    frmPiano.domusic(47) : frmPiano.domusic(54) : frmPiano.domusic(57)
                         '---------------------
                Case "C7 sus2"
                    frmPiano.domusic(36) : frmPiano.domusic(38) : frmPiano.domusic(43) : frmPiano.domusic(46)
                Case "C#7 sus2"
                    frmPiano.domusic(37) : frmPiano.domusic(39) : frmPiano.domusic(44) : frmPiano.domusic(47)
                Case "D7 sus2"
                    frmPiano.domusic(38) : frmPiano.domusic(40) : frmPiano.domusic(45) : frmPiano.domusic(48)
                Case "D#7 sus2"
                    frmPiano.domusic(39) : frmPiano.domusic(41) : frmPiano.domusic(46) : frmPiano.domusic(49)
                Case "E7 sus2"
                    frmPiano.domusic(40) : frmPiano.domusic(42) : frmPiano.domusic(47) : frmPiano.domusic(50)
                Case "F7 sus2"
                    frmPiano.domusic(41) : frmPiano.domusic(43) : frmPiano.domusic(48) : frmPiano.domusic(51)
                Case "F#7 sus2"
                    frmPiano.domusic(42) : frmPiano.domusic(44) : frmPiano.domusic(49) : frmPiano.domusic(52)
                Case "G7 sus2"
                    frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(50) : frmPiano.domusic(53)
                Case "G#7 sus2"
                    frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(51) : frmPiano.domusic(54)
                Case "A7 sus2"
                    frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(52) : frmPiano.domusic(55)
                Case "A#7 sus2"
                    frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(53) : frmPiano.domusic(56)
                Case "B7 sus2"
                    frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(54) : frmPiano.domusic(57)
                            '----------------------
                Case "C7 sus4"
                    frmPiano.domusic(36) : frmPiano.domusic(41) : frmPiano.domusic(43) : frmPiano.domusic(46)
                Case "C#7 sus4"
                    frmPiano.domusic(37) : frmPiano.domusic(42) : frmPiano.domusic(44) : frmPiano.domusic(47)
                Case "D7 sus4"
                    frmPiano.domusic(38) : frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(48)
                Case "D#7 sus4"
                    frmPiano.domusic(39) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(49)
                Case "E7 sus4"
                    frmPiano.domusic(40) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(50)
                Case "F7 sus4"
                    frmPiano.domusic(41) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(51)
                Case "F#7 sus4"
                    frmPiano.domusic(42) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(52)
                Case "G7 sus4"
                    frmPiano.domusic(43) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(53)
                Case "G#7 sus4"
                    frmPiano.domusic(44) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(54)
                Case "A7 sus4"
                    frmPiano.domusic(45) : frmPiano.domusic(50) : frmPiano.domusic(52) : frmPiano.domusic(55)
                Case "A#7 sus4"
                    frmPiano.domusic(46) : frmPiano.domusic(51) : frmPiano.domusic(53) : frmPiano.domusic(56)
                Case "B7 sus4"
                    frmPiano.domusic(47) : frmPiano.domusic(52) : frmPiano.domusic(54) : frmPiano.domusic(57)
                             '---------------------
                Case "C7 b5"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(42) : frmPiano.domusic(46)
                Case "C#7 b5"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(43) : frmPiano.domusic(47)
                Case "D7 b5"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(44) : frmPiano.domusic(48)
                Case "D#7 b5"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(49)
                Case "E7 b5"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(50)
                Case "F7 b5"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(51)
                Case "F#7 b5"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(52)
                Case "G7 b5"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(53)
                Case "G#7 b5"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(54)
                Case "A7 b5"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(55)
                Case "A#7 b5"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(52) : frmPiano.domusic(56)
                Case "B7 b5"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(53) : frmPiano.domusic(57)
                             '----------------------
                Case "C7 #5"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(46)
                Case "C#7 #5"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(47)
                Case "D7 #5"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(48)
                Case "D#7 #5"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(49)
                Case "E7 #5"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(50)
                Case "F7 #5"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(51)
                Case "F#7 #5"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(52)
                Case "G7 #5"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(53)
                Case "G#7 #5"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(54)
                Case "A7 #5"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(55)
                Case "A#7 #5"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(56)
                Case "B7 #5"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(55) : frmPiano.domusic(57)
                             '----------------------
                Case "C7 b9"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(49)
                Case "C#7 b9"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(50)
                Case "D7 b9"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(51)
                Case "D#7 b9"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(52)
                Case "E7 b9"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(53)
                Case "F7 b9"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(54)
                Case "F#7 b9"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(55)
                Case "G7 b9"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(56)
                Case "G#7 b9"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(57)
                Case "A7 b9"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(55) : frmPiano.domusic(58)
                Case "A#7 b9"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(56) : frmPiano.domusic(59)
                Case "B7 b9"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(57) : frmPiano.domusic(60)
                              '----------------------
                Case "C7 #9"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(51)
                Case "C#7 #9"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(52)
                Case "D7 #9"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(53)
                Case "D#7 #9"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(54)
                Case "E7 #9"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(55)
                Case "F7 #9"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(56)
                Case "F#7 #9"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(57)
                Case "G7 #9"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(58)
                Case "G#7 #9"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(59)
                Case "A7 #9"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(55) : frmPiano.domusic(60)
                Case "A#7 #9"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(56) : frmPiano.domusic(61)
                Case "B7 #9"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(57) : frmPiano.domusic(62)
                             '------------------------
                Case "C7 #11"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(54)
                Case "C#7 #11"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(55)
                Case "D7 #11"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(56)
                Case "D#7 #11"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(57)
                Case "E7 #11"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(58)
                Case "F7 #11"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(59)
                Case "F#7 #11"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(60)
                Case "G7 #11"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(61)
                Case "G#7 #11"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(62)
                Case "A7 #11"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(55) : frmPiano.domusic(63)
                Case "A#7 #11"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(56) : frmPiano.domusic(64)
                Case "B7 #11"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(57) : frmPiano.domusic(65)
                              '----------------------
                Case "C7-6"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(46)
                Case "C#7-6"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(47)
                Case "D7-6"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(48)
                Case "D#7-6"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(49)
                Case "E7-6"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(50)
                Case "F7-6"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(51)
                Case "F#7-6"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(52)
                Case "G7-6"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(52) : frmPiano.domusic(53)
                Case "G#7-6"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(53) : frmPiano.domusic(54)
                Case "A7-6"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(54) : frmPiano.domusic(55)
                Case "A#7-6"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(55) : frmPiano.domusic(56)
                Case "B7-6"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(56) : frmPiano.domusic(57)
                             '----------------------
                Case "C7-9"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(49)
                Case "C#7-9"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(50)
                Case "D7-9"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(51)
                Case "D#7-9"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(52)
                Case "E7-9"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(53)
                Case "F7-9"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(54)
                Case "F#7-9"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(55)
                Case "G7-9"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(56)
                Case "G#7-9"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(57)
                Case "A7-9"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(55) : frmPiano.domusic(58)
                Case "A#7-9"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(56) : frmPiano.domusic(59)
                Case "B7-9"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(57) : frmPiano.domusic(60)
                             '--------------------
                Case "C7-13"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(57)
                Case "C#7-13"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(58)
                Case "D7-13"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(59)
                Case "D#7-13"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(60)
                Case "E7-13"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(61)
                Case "F7-13"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(62)
                Case "F#7-13"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(63)
                Case "G7-13"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(64)
                Case "G#7-13"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(65)
                Case "A7-13"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(55) : frmPiano.domusic(66)
                Case "A#7-13"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(56) : frmPiano.domusic(67)
                Case "B7-13"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(57) : frmPiano.domusic(68)
                        '---------------------
                Case "C9"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50)
                Case "C#9"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51)
                Case "D9"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52)
                Case "D#9"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53)
                Case "E9"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54)
                Case "F9"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(55)
                Case "F#9"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(56)
                Case "G9"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(57)
                Case "G#9"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(58)
                Case "A9"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(55) : frmPiano.domusic(59)
                Case "A#9"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(56) : frmPiano.domusic(60)
                Case "B9"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(57) : frmPiano.domusic(61)
                             '---------------------
                Case "C9 sus"
                    frmPiano.domusic(36) : frmPiano.domusic(38) : frmPiano.domusic(43) : frmPiano.domusic(46)
                Case "C#9 sus"
                    frmPiano.domusic(37) : frmPiano.domusic(39) : frmPiano.domusic(44) : frmPiano.domusic(47)
                Case "D9 sus"
                    frmPiano.domusic(38) : frmPiano.domusic(40) : frmPiano.domusic(45) : frmPiano.domusic(48)
                Case "D#9 sus"
                    frmPiano.domusic(39) : frmPiano.domusic(41) : frmPiano.domusic(46) : frmPiano.domusic(49)
                Case "E9 sus"
                    frmPiano.domusic(40) : frmPiano.domusic(42) : frmPiano.domusic(47) : frmPiano.domusic(50)
                Case "F9 sus"
                    frmPiano.domusic(41) : frmPiano.domusic(43) : frmPiano.domusic(48) : frmPiano.domusic(51)
                Case "F#9 sus"
                    frmPiano.domusic(42) : frmPiano.domusic(44) : frmPiano.domusic(49) : frmPiano.domusic(52)
                Case "G9 sus"
                    frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(50) : frmPiano.domusic(53)
                Case "G#9 sus"
                    frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(51) : frmPiano.domusic(54)
                Case "A9 sus"
                    frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(52) : frmPiano.domusic(55)
                Case "A#9 sus"
                    frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(53) : frmPiano.domusic(56)
                Case "B9 sus"
                    frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(54) : frmPiano.domusic(57)
                            '-----------------------
                Case "C9 sus4"
                    frmPiano.domusic(36) : frmPiano.domusic(41) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50)
                Case "C#9 sus4"
                    frmPiano.domusic(37) : frmPiano.domusic(42) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51)
                Case "D9 sus4"
                    frmPiano.domusic(38) : frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52)
                Case "D#9 sus4"
                    frmPiano.domusic(39) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53)
                Case "E9 sus4"
                    frmPiano.domusic(40) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54)
                Case "F9 sus4"
                    frmPiano.domusic(41) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(55)
                Case "F#9 sus4"
                    frmPiano.domusic(42) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(56)
                Case "G9 sus4"
                    frmPiano.domusic(43) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(57)
                Case "G#9 sus4"
                    frmPiano.domusic(44) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(58)
                Case "A9 sus4"
                    frmPiano.domusic(45) : frmPiano.domusic(50) : frmPiano.domusic(52) : frmPiano.domusic(55) : frmPiano.domusic(59)
                Case "A#9 sus4"
                    frmPiano.domusic(46) : frmPiano.domusic(51) : frmPiano.domusic(53) : frmPiano.domusic(56) : frmPiano.domusic(60)
                Case "B9 sus4"
                    frmPiano.domusic(47) : frmPiano.domusic(52) : frmPiano.domusic(54) : frmPiano.domusic(57) : frmPiano.domusic(61)
                               '-------------------
                Case "C9 b5"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(50)
                Case "C#9 b5"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(51)
                Case "D9 b5"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(52)
                Case "D#9 b5"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(53)
                Case "E9 b5"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(54)
                Case "F9 b5"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(55)
                Case "F#9 b5"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(56)
                Case "G9 b5"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(57)
                Case "G#9 b5"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(58)
                Case "A9 b5"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(55) : frmPiano.domusic(59)
                Case "A#9 b5"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(52) : frmPiano.domusic(56) : frmPiano.domusic(60)
                Case "B9 b5"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(53) : frmPiano.domusic(57) : frmPiano.domusic(61)
                              '----------------------          
                Case "C11"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53)
                Case "C#11"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54)
                Case "D11"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(55)
                Case "D#11"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(56)
                Case "E11"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(57)
                Case "F11"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(55) : frmPiano.domusic(58)
                Case "F#11"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(56) : frmPiano.domusic(59)
                Case "G11"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(57) : frmPiano.domusic(60)
                Case "G#11"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(58) : frmPiano.domusic(61)
                Case "A11"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(55) : frmPiano.domusic(59) : frmPiano.domusic(62)
                Case "A#11"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(56) : frmPiano.domusic(60) : frmPiano.domusic(63)
                Case "B11"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(57) : frmPiano.domusic(61) : frmPiano.domusic(64)
                              '---------------------
                Case "C-#11"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(54)
                Case "C#-#11"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(55)
                Case "D-#11"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(56)
                Case "D#-#11"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(57)
                Case "E-#11"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(58)
                Case "F-#11"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(59)
                Case "F#-#11"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(60)
                Case "G-#11"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(61)
                Case "G#-#11"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(62)
                Case "A-#11"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(63)
                Case "A#-#11"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(64)
                Case "B-#11"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(65)
                      '----------------------
                Case "C11 sus4"
                    frmPiano.domusic(36) : frmPiano.domusic(41) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53)
                Case "C#11 sus4"
                    frmPiano.domusic(37) : frmPiano.domusic(42) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54)
                Case "D11 sus4"
                    frmPiano.domusic(38) : frmPiano.domusic(43) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(55)
                Case "D#11 sus4"
                    frmPiano.domusic(39) : frmPiano.domusic(44) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(56)
                Case "E11 sus4"
                    frmPiano.domusic(40) : frmPiano.domusic(45) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(57)
                Case "F11 sus4"
                    frmPiano.domusic(41) : frmPiano.domusic(46) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(55) : frmPiano.domusic(58)
                Case "F#11 sus4"
                    frmPiano.domusic(42) : frmPiano.domusic(47) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(56) : frmPiano.domusic(59)
                Case "G11 sus4"
                    frmPiano.domusic(43) : frmPiano.domusic(48) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(57) : frmPiano.domusic(60)
                Case "G#11 sus4"
                    frmPiano.domusic(44) : frmPiano.domusic(49) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(58) : frmPiano.domusic(61)
                Case "A11 sus4"
                    frmPiano.domusic(45) : frmPiano.domusic(50) : frmPiano.domusic(52) : frmPiano.domusic(55) : frmPiano.domusic(59) : frmPiano.domusic(62)
                Case "A#11 sus4"
                    frmPiano.domusic(46) : frmPiano.domusic(51) : frmPiano.domusic(53) : frmPiano.domusic(56) : frmPiano.domusic(60) : frmPiano.domusic(63)
                Case "B11 sus4"
                    frmPiano.domusic(47) : frmPiano.domusic(52) : frmPiano.domusic(54) : frmPiano.domusic(57) : frmPiano.domusic(61) : frmPiano.domusic(64)
                             '--------------------
                Case "C13"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(57)
                Case "C#13"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(58)
                Case "D13"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(55) : frmPiano.domusic(59)
                Case "D#13"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(56) : frmPiano.domusic(60)
                Case "E13"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(57) : frmPiano.domusic(61)
                Case "F13"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(55) : frmPiano.domusic(58) : frmPiano.domusic(62)
                Case "F#13"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(56) : frmPiano.domusic(59) : frmPiano.domusic(63)
                Case "G13"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(57) : frmPiano.domusic(60) : frmPiano.domusic(64)
                Case "G#13"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(58) : frmPiano.domusic(61) : frmPiano.domusic(65)
                Case "A13"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(55) : frmPiano.domusic(59) : frmPiano.domusic(62) : frmPiano.domusic(66)
                Case "A#13"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(56) : frmPiano.domusic(60) : frmPiano.domusic(63) : frmPiano.domusic(67)
                Case "B13"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(57) : frmPiano.domusic(61) : frmPiano.domusic(64) : frmPiano.domusic(68)
                           '------------------------
                Case "C13 #11"
                    frmPiano.domusic(36) : frmPiano.domusic(40) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(57)
                Case "C#13 #11"
                    frmPiano.domusic(37) : frmPiano.domusic(41) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(55) : frmPiano.domusic(58)
                Case "D13 #11"
                    frmPiano.domusic(38) : frmPiano.domusic(42) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(52) : frmPiano.domusic(56) : frmPiano.domusic(59)
                Case "D#13 #11"
                    frmPiano.domusic(39) : frmPiano.domusic(43) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(53) : frmPiano.domusic(57) : frmPiano.domusic(60)
                Case "E13 #11"
                    frmPiano.domusic(40) : frmPiano.domusic(44) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(54) : frmPiano.domusic(58) : frmPiano.domusic(61)
                Case "F13 #11"
                    frmPiano.domusic(41) : frmPiano.domusic(45) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(55) : frmPiano.domusic(59) : frmPiano.domusic(62)
                Case "F#13 #11"
                    frmPiano.domusic(42) : frmPiano.domusic(46) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(56) : frmPiano.domusic(60) : frmPiano.domusic(63)
                Case "G13 #11"
                    frmPiano.domusic(43) : frmPiano.domusic(47) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(57) : frmPiano.domusic(61) : frmPiano.domusic(64)
                Case "G#13 #11"
                    frmPiano.domusic(44) : frmPiano.domusic(48) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(58) : frmPiano.domusic(62) : frmPiano.domusic(65)
                Case "A13 #11"
                    frmPiano.domusic(45) : frmPiano.domusic(49) : frmPiano.domusic(52) : frmPiano.domusic(55) : frmPiano.domusic(59) : frmPiano.domusic(63) : frmPiano.domusic(66)
                Case "A#13 #11"
                    frmPiano.domusic(46) : frmPiano.domusic(50) : frmPiano.domusic(53) : frmPiano.domusic(56) : frmPiano.domusic(60) : frmPiano.domusic(64) : frmPiano.domusic(67)
                Case "B13 #11"
                    frmPiano.domusic(47) : frmPiano.domusic(51) : frmPiano.domusic(54) : frmPiano.domusic(57) : frmPiano.domusic(61) : frmPiano.domusic(65) : frmPiano.domusic(68)


            End Select
        End Function

    Public Function playChordE(ChordName As String) As String

            Select Case ChordName

                Case "0"
                    frmPiano.domusicstop(0) : Case "1" : frmPiano.domusicstop(1) : Case "2" : frmPiano.domusicstop(2) : Case "3" : frmPiano.domusicstop(3) : Case "4" : frmPiano.domusicstop(4) : Case "5" : frmPiano.domusicstop(5) : Case "6" : frmPiano.domusicstop(6) : Case "7" : frmPiano.domusicstop(7) : Case "8" : frmPiano.domusicstop(8) : Case "9" : frmPiano.domusicstop(9) : Case "10" : frmPiano.domusicstop(10) : Case "11" : frmPiano.domusicstop(11)
                Case "12"
                    frmPiano.domusicstop(12) : Case "13" : frmPiano.domusicstop(13) : Case "14" : frmPiano.domusicstop(14) : Case "15" : frmPiano.domusicstop(15) : Case "16" : frmPiano.domusicstop(16) : Case "17" : frmPiano.domusicstop(17) : Case "18" : frmPiano.domusicstop(18) : Case "19" : frmPiano.domusicstop(19) : Case "20" : frmPiano.domusicstop(20) : Case "21" : frmPiano.domusicstop(21) : Case "22" : frmPiano.domusicstop(22) : Case "23" : frmPiano.domusicstop(23)
                Case "24"
                    frmPiano.domusicstop(24) : Case "25" : frmPiano.domusicstop(25) : Case "26" : frmPiano.domusicstop(26) : Case "27" : frmPiano.domusicstop(27) : Case "28" : frmPiano.domusicstop(28) : Case "29" : frmPiano.domusicstop(29) : Case "30" : frmPiano.domusicstop(30) : Case "31" : frmPiano.domusicstop(31) : Case "32" : frmPiano.domusicstop(32) : Case "33" : frmPiano.domusicstop(33) : Case "34" : frmPiano.domusicstop(34) : Case "35" : frmPiano.domusicstop(35)
                Case "36"
                    frmPiano.domusicstop(36) : Case "37" : frmPiano.domusicstop(37) : Case "38" : frmPiano.domusicstop(38) : Case "39" : frmPiano.domusicstop(39) : Case "40" : frmPiano.domusicstop(40) : Case "41" : frmPiano.domusicstop(41) : Case "42" : frmPiano.domusicstop(42) : Case "43" : frmPiano.domusicstop(43) : Case "44" : frmPiano.domusicstop(44) : Case "45" : frmPiano.domusicstop(45) : Case "46" : frmPiano.domusicstop(46)


                Case "CMaj"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43)
                Case "C#Maj"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44)
                Case "DMaj"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45)
                Case "D#Maj"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46)
                Case "EMaj"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47)
                Case "FMaj"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48)
                Case "F#Maj"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49)
                Case "GMaj"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50)
                Case "G#Maj"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51)
                Case "AMaj"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52)
                Case "A#Maj"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53)
                Case "BMaj"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54)

                                  '-----------------------------
                Case "CMaj 7"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47)
                Case "C#Maj 7"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48)
                Case "DMaj 7"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49)
                Case "D#Maj 7"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50)
                Case "EMaj 7"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51)
                Case "FMaj 7"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52)
                Case "F#Maj 7"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53)
                Case "GMaj 7"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54)
                Case "G#Maj 7"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55)
                Case "AMaj 7"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56)
                Case "A#Maj 7"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57)
                Case "BMaj 7"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58)

                                   '---------------------------                      
                Case "CMaj 9"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50)
                Case "C#Maj 9"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51)
                Case "DMaj 9"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52)
                Case "D#Maj 9"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53)
                Case "EMaj 9"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54)
                Case "FMaj 9"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55)
                Case "F#Maj 9"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56)
                Case "GMaj 9"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57)
                Case "G#Maj 9"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55) : frmPiano.domusicstop(58)
                Case "AMaj 9"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56) : frmPiano.domusicstop(59)
                Case "A#Maj 9"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57) : frmPiano.domusicstop(60)
                Case "BMaj 9"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58) : frmPiano.domusicstop(61)

                              '------------------------------
                Case "CMaj 11"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53)
                Case "C#Maj 11"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54)
                Case "DMaj 11"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55)
                Case "D#Maj 11"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56)
                Case "EMaj 11"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57)
                Case "FMaj 11"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55) : frmPiano.domusicstop(58)
                Case "F#Maj 11"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56) : frmPiano.domusicstop(59)
                Case "GMaj 11"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57) : frmPiano.domusicstop(60)
                Case "G#Maj 11"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55) : frmPiano.domusicstop(58) : frmPiano.domusicstop(61)
                Case "AMaj 11"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56) : frmPiano.domusicstop(59) : frmPiano.domusicstop(62)
                Case "A#Maj 11"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57) : frmPiano.domusicstop(60) : frmPiano.domusicstop(63)
                Case "BMaj 11"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58) : frmPiano.domusicstop(61) : frmPiano.domusicstop(64)

                                                    '--------------------------------------------
                Case "CMaj 13"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57)
                Case "C#Maj 13"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58)
                Case "DMaj 13"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55) : frmPiano.domusicstop(59)
                Case "D#Maj 13"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56) : frmPiano.domusicstop(60)
                Case "EMaj 13"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57) : frmPiano.domusicstop(61)
                Case "FMaj 13"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55) : frmPiano.domusicstop(58) : frmPiano.domusicstop(62)
                Case "F#Maj 13"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56) : frmPiano.domusicstop(59) : frmPiano.domusicstop(63)
                Case "GMaj 13"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57) : frmPiano.domusicstop(60) : frmPiano.domusicstop(64)
                Case "G#Maj 13"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55) : frmPiano.domusicstop(58) : frmPiano.domusicstop(61) : frmPiano.domusicstop(65)
                Case "AMaj 13"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56) : frmPiano.domusicstop(59) : frmPiano.domusicstop(62) : frmPiano.domusicstop(66)
                Case "A#Maj 13"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57) : frmPiano.domusicstop(60) : frmPiano.domusicstop(63) : frmPiano.domusicstop(67)
                Case "BMaj 13"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58) : frmPiano.domusicstop(61) : frmPiano.domusicstop(64) : frmPiano.domusicstop(68)

                                                          '---------------------------------------------------
                Case "CMaj 7 b5"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(42) : frmPiano.domusicstop(47)
                Case "C#Maj 7 b5"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(43) : frmPiano.domusicstop(48)
                Case "DMaj 7 b5"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(44) : frmPiano.domusicstop(49)
                Case "D#Maj 7 b5"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(50)
                Case "EMaj 7 b5"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(51)
                Case "FMaj 7 b5"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(52)
                Case "F#Maj 7 b5"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(53)
                Case "GMaj 7 b5"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(54)
                Case "G#Maj 7 b5"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(55)
                Case "AMaj 7 b5"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(56)
                Case "A#Maj 7 b5"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52) : frmPiano.domusicstop(57)
                Case "BMaj 7 b5"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53) : frmPiano.domusicstop(58)

                                       '-------------------------
                Case "CMaj 7 #5"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47)
                Case "C#Maj 7 #5"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48)
                Case "DMaj 7 #5"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49)
                Case "D#Maj 7 #5"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50)
                Case "EMaj 7 #5"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51)
                Case "FMaj 7 #5"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52)
                Case "F#Maj 7 #5"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53)
                Case "GMaj 7 #5"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54)
                Case "G#Maj 7 #5"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55)
                Case "AMaj 7 #5"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56)
                Case "A#Maj 7 #5"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57)
                Case "BMaj 7 #5"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55) : frmPiano.domusicstop(58)
                                                '------------------------------------------                  

                Case "CMaj 7 b9"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49)

                Case "C#Maj 7 b9"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50)

                Case "DMaj 7 b9"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51)

                Case "D#Maj 7 b9"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52)

                Case "EMaj 7 b9"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53)

                Case "FMaj 7 b9"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54)

                Case "F#Maj 7 b9"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(55)

                Case "GMaj 7 b9"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(56)

                Case "G#Maj 7 b9"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55) : frmPiano.domusicstop(57)

                Case "AMaj 7 b9"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56) : frmPiano.domusicstop(58)

                Case "A#Maj 7 b9"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57) : frmPiano.domusicstop(59)

                Case "BMaj 7 b9"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58) : frmPiano.domusicstop(60)

                                               '---------------------------------
                Case "CMaj 7 #9"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51)

                Case "C#Maj 7 #9"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52)

                Case "DMaj 7 #9"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53)

                Case "D#Maj 7 #9"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54)

                Case "EMaj 7 #9"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55)

                Case "FMaj 7 #9"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56)

                Case "F#Maj 7 #9"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57)

                Case "GMaj 7 #9"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58)

                Case "G#Maj 7 #9"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55) : frmPiano.domusicstop(59)

                Case "AMaj 7 #9"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56) : frmPiano.domusicstop(60)

                Case "A#Maj 7 #9"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57) : frmPiano.domusicstop(61)

                Case "BMaj 7 #9"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58) : frmPiano.domusicstop(62)

                                                '----------------------------------------
                Case "CMaj 7sus2"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(38) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47)

                Case "C#Maj 7sus2"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(39) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48)

                Case "DMaj 7sus2"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(40) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49)

                Case "D#Maj 7sus2"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(41) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50)

                Case "EMaj 7sus2"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(42) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51)

                Case "FMaj 7sus2"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(43) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52)

                Case "F#Maj 7sus2"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(44) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53)

                Case "GMaj 7sus2"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54)

                Case "G#Maj 7sus2"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55)

                Case "AMaj 7sus2"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56)

                Case "A#Maj 7sus2"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57)

                Case "BMaj 7sus2"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58)
                                   '-----------------------------------
                Case "CMaj 7sus4"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(41) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47)

                Case "C#Maj 7sus4"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(42) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48)

                Case "DMaj 7sus4"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49)

                Case "D#Maj 7sus4"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50)

                Case "EMaj 7sus4"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51)

                Case "FMaj 7sus4"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52)

                Case "F#Maj 7sus4"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53)

                Case "GMaj 7sus4"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54)

                Case "G#Maj 7sus4"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55)

                Case "AMaj 7sus4"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56)

                Case "A#Maj 7sus4"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57)

                Case "BMaj 7sus4"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58)
                                          '-------------------------------
                Case "CMaj 9 b5"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(42) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50)

                Case "C#Maj 9 b5"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(43) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51)

                Case "DMaj 9 b5"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(44) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52)

                Case "D#Maj 9 b5"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53)

                Case "EMaj 9 b5"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54)

                Case "FMaj 9 b5"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55)

                Case "F#Maj 9 b5"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56)

                Case "GMaj 9 b5"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57)

                Case "G#Maj 9 b5"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(55) : frmPiano.domusicstop(58)

                Case "AMaj 9 b5"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(56) : frmPiano.domusicstop(59)

                Case "A#Maj 9 b5"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52) : frmPiano.domusicstop(57) : frmPiano.domusicstop(60)

                Case "BMaj 9 b5"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53) : frmPiano.domusicstop(58) : frmPiano.domusicstop(61)
                                                      '------------------------------

                Case "CMaj 7 #11"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(54)

                Case "C#Maj 7 #11"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(55)

                Case "DMaj 7 #11"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(56)

                Case "D#Maj 7 #11"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(57)

                Case "EMaj 7 #11"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(58)

                Case "FMaj 7 #11"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(59)

                Case "F#Maj 7 #11"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(60)

                Case "GMaj 7 #11"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(61)

                Case "G#Maj 7 #11"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55) : frmPiano.domusicstop(62)

                Case "AMaj 7 #11"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56) : frmPiano.domusicstop(63)

                Case "A#Maj 7 #11"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57) : frmPiano.domusicstop(64)

                Case "BMaj 7 #11"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58) : frmPiano.domusicstop(65)

                                                   '-------------------------------
                Case "CMaj 9 #11"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54)

                Case "C#Maj 9 #11"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55)

                Case "DMaj 9 #11"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56)

                Case "D#Maj 9 #11"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57)

                Case "EMaj 9 #11"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58)

                Case "FMaj 9 #11"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55) : frmPiano.domusicstop(59)

                Case "F#Maj 9 #11"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56) : frmPiano.domusicstop(60)

                Case "GMaj 9 #11"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57) : frmPiano.domusicstop(61)

                Case "G#Maj 9 #11"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55) : frmPiano.domusicstop(58) : frmPiano.domusicstop(62)

                Case "AMaj 9 #11"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56) : frmPiano.domusicstop(59) : frmPiano.domusicstop(63)

                Case "A#Maj 9 #11"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57) : frmPiano.domusicstop(60) : frmPiano.domusicstop(64)

                Case "BMaj 9 #11"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58) : frmPiano.domusicstop(61) : frmPiano.domusicstop(65)

                                           '------------------------------
                Case "CMaj7add11"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(53)

                Case "C#Maj7add11"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(54)

                Case "DMaj7add11"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(55)

                Case "D#Maj7add11"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(56)

                Case "EMaj7add11"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(57)

                Case "FMaj7add11"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(58)

                Case "F#Maj7add11"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(59)

                Case "GMaj7add11"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(60)

                Case "G#Maj7add11"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55) : frmPiano.domusicstop(61)

                Case "AMaj7add11"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56) : frmPiano.domusicstop(62)

                Case "A#Maj7add11"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57) : frmPiano.domusicstop(63)

                Case "BMaj7add11"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58) : frmPiano.domusicstop(64)

                                            '--------------------------------
                Case "CMaj 69"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(50)

                Case "C#Maj 69"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(51)

                Case "DMaj 69"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(52)

                Case "D#Maj 69"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(53)

                Case "EMaj 69"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(54)

                Case "FMaj 69"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(55)

                Case "F#Maj 69"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(56)

                Case "GMaj 69"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52) : frmPiano.domusicstop(57)

                Case "G#Maj 69"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53) : frmPiano.domusicstop(58)

                Case "AMaj 69"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54) : frmPiano.domusicstop(59)

                Case "A#Maj 69"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(55) : frmPiano.domusicstop(60)

                Case "BMaj 69"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(56) : frmPiano.domusicstop(61)

                                                    '--------------------------------

                Case "Cmin"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(43)

                Case "C#min"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(44)

                Case "Dmin"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(45)

                Case "D#min"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(46)

                Case "Emin"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47)

                Case "Fmin"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48)

                Case "F#min"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49)

                Case "Gmin"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50)

                Case "G#min"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51)

                Case "Amin"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52)

                Case "A#min"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53)

                Case "Bmin"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54)

                                                    '----------------------------

                Case "Cmin 7"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46)

                Case "C#min 7"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47)

                Case "Dmin 7"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48)

                Case "D#min 7"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49)

                Case "Emin 7"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50)

                Case "Fmin 7"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51)

                Case "F#min 7"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52)

                Case "Gmin 7"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53)

                Case "G#min 7"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54)

                Case "Amin 7"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55)

                Case "A#min 7"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56)

                Case "Bmin 7"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57)
                                       '-----------------------------------
                Case "Cmin 9"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50)

                Case "C#min 9"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51)

                Case "Dmin 9"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52)

                Case "D#min 9"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53)

                Case "Emin 9"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54)

                Case "Fmin 9"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55)

                Case "F#min 9"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56)

                Case "Gmin 9"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57)

                Case "G#min 9"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58)

                Case "Amin 9"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55) : frmPiano.domusicstop(59)

                Case "A#min 9"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56) : frmPiano.domusicstop(60)

                Case "Bmin 9"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57) : frmPiano.domusicstop(61)
                               '----------------------------------
                Case "Cmin 11"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53)

                Case "C#min 11"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54)

                Case "Dmin 11"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55)

                Case "D#min 11"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56)

                Case "Emin 11"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57)

                Case "Fmin 11"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55) : frmPiano.domusicstop(58)

                Case "F#min 11"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56) : frmPiano.domusicstop(59)

                Case "Gmin 11"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57) : frmPiano.domusicstop(60)

                Case "G#min 11"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58) : frmPiano.domusicstop(61)

                Case "Amin 11"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55) : frmPiano.domusicstop(59) : frmPiano.domusicstop(62)

                Case "A#min 11"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56) : frmPiano.domusicstop(60) : frmPiano.domusicstop(63)

                Case "Bmin 11"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57) : frmPiano.domusicstop(61) : frmPiano.domusicstop(64)
                              '------------------------------
                Case "Cmin 13"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57)

                Case "C#min 13"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58)

                Case "Dmin 13"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55) : frmPiano.domusicstop(59)

                Case "D#min 13"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56) : frmPiano.domusicstop(60)

                Case "Emin 13"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57) : frmPiano.domusicstop(61)

                Case "Fmin 13"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55) : frmPiano.domusicstop(58) : frmPiano.domusicstop(62)

                Case "F#min 13"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56) : frmPiano.domusicstop(59) : frmPiano.domusicstop(63)

                Case "Gmin 13"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57) : frmPiano.domusicstop(60) : frmPiano.domusicstop(64)

                Case "G#min 13"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58) : frmPiano.domusicstop(61) : frmPiano.domusicstop(65)

                Case "Amin 13"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55) : frmPiano.domusicstop(59) : frmPiano.domusicstop(62) : frmPiano.domusicstop(66)

                Case "A#min 13"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56) : frmPiano.domusicstop(60) : frmPiano.domusicstop(63) : frmPiano.domusicstop(67)

                Case "Bmin 13"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57) : frmPiano.domusicstop(61) : frmPiano.domusicstop(64) : frmPiano.domusicstop(68)
                              '-------------------------------
                Case "Cmin 7 b5"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(46)

                Case "C#min 7 b5"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47)

                Case "Dmin 7 b5"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48)

                Case "D#min 7 b5"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49)

                Case "Emin 7 b5"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50)

                Case "Fmin 7 b5"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51)

                Case "F#min 7 b5"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52)

                Case "Gmin 7 b5"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53)

                Case "G#min 7 b5"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54)

                Case "Amin 7 b5"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55)

                Case "A#min 7 b5"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56)

                Case "Bmin 7 b5"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57)
                              '-------------------------------------
                Case "Cmin 7 #5"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46)

                Case "C#min 7 #5"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47)

                Case "Dmin 7 #5"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48)

                Case "D#min 7 #5"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49)

                Case "Emin 7 #5"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50)

                Case "Fmin 7 #5"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51)

                Case "F#min 7 #5"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52)

                Case "Gmin 7 #5"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53)

                Case "G#min 7 #5"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54)

                Case "Amin 7 #5"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(53) : frmPiano.domusicstop(55)

                Case "A#min 7 #5"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(54) : frmPiano.domusicstop(56)

                Case "Bmin 7 #5"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(55) : frmPiano.domusicstop(57)
                              '---------------------------------
                Case "Cmin 7 #9"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(51)

                Case "C#min 7 #9"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(52)

                Case "Dmin 7 #9"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(53)

                Case "D#min 7 #9"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(54)

                Case "Emin 7 #9"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(55)

                Case "Fmin 7 #9"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(56)

                Case "F#min 7 #9"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(57)

                Case "Gmin 7 #9"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(58)

                Case "G#min 7 #9"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(59)

                Case "Amin 7 #9"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55) : frmPiano.domusicstop(60)

                Case "A#min 7 #9"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56) : frmPiano.domusicstop(61)

                Case "Bmin 7 #9"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57) : frmPiano.domusicstop(62)
                                '-----------------------
                Case "Cmin7add11"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(53)

                Case "C#min7add11"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(54)

                Case "Dmin7add11"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(55)

                Case "D#min7add11"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(56)

                Case "Emin7add11"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(57)

                Case "Fmin7add11"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(58)

                Case "F#min7add11"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(59)

                Case "Gmin7add11"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(60)

                Case "G#min7add11"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(61)

                Case "Amin7add11"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55) : frmPiano.domusicstop(62)

                Case "A#min7add11"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56) : frmPiano.domusicstop(63)

                Case "Bmin7add11"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57) : frmPiano.domusicstop(64)
                              '--------------------------
                Case "Cmin 9 #5"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50)

                Case "C#min 9 #5"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51)

                Case "Dmin 9 #5"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52)

                Case "D#min 9 #5"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53)

                Case "Emin 9 #5"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54)

                Case "Fmin 9 #5"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55)

                Case "F#min 9 #5"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56)

                Case "Gmin 9 #5"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57)

                Case "G#min 9 #5"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58)

                Case "Amin 9 #5"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(53) : frmPiano.domusicstop(55) : frmPiano.domusicstop(59)

                Case "A#min 9 #5"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(54) : frmPiano.domusicstop(56) : frmPiano.domusicstop(60)

                Case "Bmin 9 #5"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(55) : frmPiano.domusicstop(57) : frmPiano.domusicstop(61)
                              '----------------------------
                Case "Cmin 6"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45)
                Case "C#min 6"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46)
                Case "Dmin 6"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47)
                Case "D#min 6"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48)
                Case "Emin 6"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49)
                Case "Fmin 6"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50)
                Case "F#min 6"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51)
                Case "Gmin 6"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52)
                Case "G#min 6"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53)
                Case "Amin 6"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54)
                Case "A#min 6"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(55)
                Case "Bmin 6"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(56)
                             '---------------------------
                Case "Cmin 69"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(50)

                Case "C#min 69"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(51)

                Case "Dmin 69"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(52)

                Case "D#min 69"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(53)

                Case "Emin 69"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(54)

                Case "Fmin 69"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(55)

                Case "F#min 69"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(56)

                Case "Gmin 69"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52) : frmPiano.domusicstop(57)

                Case "G#min 69"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53) : frmPiano.domusicstop(58)

                Case "Amin 69"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54) : frmPiano.domusicstop(59)

                Case "A#min 69"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(55) : frmPiano.domusicstop(60)

                Case "Bmin 69"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(56) : frmPiano.domusicstop(61)
                            '-----------------------
                Case "CminMaj 7"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47)
                Case "C#minMaj 7"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48)
                Case "DminMaj 7"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49)
                Case "D#minMaj 7"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50)
                Case "EminMaj 7"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51)
                Case "FminMaj 7"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52)
                Case "F#minMaj 7"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53)
                Case "GminMaj 7"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54)
                Case "G#minMaj 7"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55)
                Case "AminMaj 7"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56)
                Case "A#minMaj 7"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57)
                Case "BminMaj 7"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58)
                              '--------------------------
                Case "CminMaj 9"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51)
                Case "C#minMaj 9"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52)
                Case "DminMaj 9"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53)
                Case "D#minMaj 9"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54)
                Case "EminMaj 9"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55)
                Case "FminMaj 9"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56)
                Case "F#minMaj 9"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57)
                Case "GminMaj 9"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58)
                Case "G#minMaj 9"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55) : frmPiano.domusicstop(59)
                Case "AminMaj 9"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56) : frmPiano.domusicstop(60)
                Case "A#minMaj 9"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57) : frmPiano.domusicstop(61)
                Case "BminMaj 9"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58) : frmPiano.domusicstop(62)
                              '--------------------------
                Case "Cmin add4"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(41) : frmPiano.domusicstop(43)
                Case "C#min add4"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(42) : frmPiano.domusicstop(44)
                Case "Dmin add4"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45)
                Case "D#min add4"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46)
                Case "Emin add4"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47)
                Case "Fmin add4"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48)
                Case "F#min add4"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49)
                Case "Gmin add4"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50)
                Case "G#min add4"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51)
                Case "Amin add4"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52)
                Case "A#min add4"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53)
                Case "Bmin add4"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54)
                             '---------------------------
                Case "Cmin add9"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(50)
                Case "C#min add9"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(51)
                Case "Dmin add9"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(52)
                Case "D#min add9"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(53)
                Case "Emin add9"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(54)
                Case "Fmin add9"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(55)
                Case "F#min add9"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(56)
                Case "Gmin add9"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(57)
                Case "G#min add9"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(58)
                Case "Amin add9"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(59)
                Case "A#min add9"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(60)
                Case "Bmin add9"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(61)
                             '------------------------
                Case "Cmin6 add4"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(41) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45)
                Case "C#min6 add4"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(42) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46)
                Case "Dmin6 add4"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47)
                Case "D#min6 add4"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48)
                Case "Emin6 add4"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49)
                Case "Fmin6 add4"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50)
                Case "F#min6 add4"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51)
                Case "Gmin6 add4"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52)
                Case "G#min6 add4"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53)
                Case "Amin6 add4"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54)
                Case "A#min6 add4"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53) : frmPiano.domusicstop(55)
                Case "Bmin6 add4"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54) : frmPiano.domusicstop(56)
                              '------------------------------------------------
                Case "Cmin7 add4"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(41) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46)
                Case "C#min7 add4"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(42) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47)
                Case "Dmin7 add4"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48)
                Case "D#min7 add4"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49)
                Case "Emin7 add4"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50)
                Case "Fmin7 add4"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51)
                Case "F#min7 add4"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52)
                Case "Gmin7 add4"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53)
                Case "G#min7 add4"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54)
                Case "Amin7 add4"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55)
                Case "A#min7 add4"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56)
                Case "Bmin7 add4"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57)
                                            '------------------------------------
                Case "Cmin7 #5#9"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(51)
                Case "C#min7 #5#9"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(52)
                Case "Dmin7 #5#9"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(53)
                Case "D#min7 #5#9"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(54)
                Case "Emin7 #5#9"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(55)
                Case "Fmin7 #5#9"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(56)
                Case "F#min7 #5#9"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52) : frmPiano.domusicstop(57)
                Case "Gmin7 #5#9"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53) : frmPiano.domusicstop(58)
                Case "G#min7 #5#9"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54) : frmPiano.domusicstop(59)
                Case "Amin7 #5#9"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(53) : frmPiano.domusicstop(55) : frmPiano.domusicstop(60)
                Case "A#min7 #5#9"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(54) : frmPiano.domusicstop(56) : frmPiano.domusicstop(61)
                Case "Bmin7 #5#9"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(55) : frmPiano.domusicstop(57) : frmPiano.domusicstop(62)
                               '----------------------------------
                Case "Cmin9 add6"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(50)
                Case "C#min9 add6"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(51)
                Case "Dmin9 add6"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(52)
                Case "D#min9 add6"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(53)
                Case "Emin9 add6"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(54)
                Case "Fmin9 add6"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(55)
                Case "F#min9 add6"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(56)
                Case "Gmin9 add6"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52) : frmPiano.domusicstop(57)
                Case "G#min9 add6"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53) : frmPiano.domusicstop(58)
                Case "Amin9 add6"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54) : frmPiano.domusicstop(59)
                Case "A#min9 add6"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(55) : frmPiano.domusicstop(60)
                Case "Bmin9 add6"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(56) : frmPiano.domusicstop(61)
                               '----------------------------------------
                Case "Cmin 11 b5"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53)
                Case "C#min 11 b5"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54)
                Case "Dmin 11 b5"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55)
                Case "D#min 11 b5"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56)
                Case "Emin 11 b5"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57)
                Case "Fmin 11 b5"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55) : frmPiano.domusicstop(58)
                Case "F#min 11 b5"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56) : frmPiano.domusicstop(59)
                Case "Gmin 11 b5"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57) : frmPiano.domusicstop(60)
                Case "G#min 11 b5"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58) : frmPiano.domusicstop(61)
                Case "Amin 11 b5"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55) : frmPiano.domusicstop(59) : frmPiano.domusicstop(62)
                Case "A#min 11 b5"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56) : frmPiano.domusicstop(60) : frmPiano.domusicstop(63)
                Case "Bmin 11 b5"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57) : frmPiano.domusicstop(61) : frmPiano.domusicstop(64)
                               '-------------------------------------
                Case "Cmin11#5#9"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53)
                Case "C#min11#5#9"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54)
                Case "Dmin11#5#9"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(53) : frmPiano.domusicstop(55)
                Case "D#min11#5#9"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(54) : frmPiano.domusicstop(56)
                Case "Emin11#5#9"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(55) : frmPiano.domusicstop(57)
                Case "Fmin11#5#9"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(56) : frmPiano.domusicstop(58)
                Case "F#min11#5#9"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52) : frmPiano.domusicstop(57) : frmPiano.domusicstop(59)
                Case "Gmin11#5#9"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53) : frmPiano.domusicstop(58) : frmPiano.domusicstop(60)
                Case "G#min11#5#9"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54) : frmPiano.domusicstop(59) : frmPiano.domusicstop(61)
                Case "Amin11#5#9"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(53) : frmPiano.domusicstop(55) : frmPiano.domusicstop(60) : frmPiano.domusicstop(62)
                Case "A#min11#5#9"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(54) : frmPiano.domusicstop(56) : frmPiano.domusicstop(61) : frmPiano.domusicstop(63)
                Case "Bmin11#5#9"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(55) : frmPiano.domusicstop(57) : frmPiano.domusicstop(62) : frmPiano.domusicstop(64)
                               '-------------------------------
                Case "Csus2 sus4"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(43)
                Case "C#sus2 sus4"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(44)
                Case "Dsus2 sus4"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45)
                Case "D#sus2 sus4"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46)
                Case "Esus2 sus4"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47)
                Case "Fsus2 sus4"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48)
                Case "F#sus2 sus4"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49)
                Case "Gsus2 sus4"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50)
                Case "G#sus2 sus4"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51)
                Case "Asus2 sus4"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52)
                Case "A#sus2 sus4"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53)
                Case "Bsus2 sus4"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54)
                               '------------------------------
                Case "Csus 2"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(38) : frmPiano.domusicstop(43)
                Case "C#sus 2"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(39) : frmPiano.domusicstop(44)
                Case "Dsus 2"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(40) : frmPiano.domusicstop(45)
                Case "D#sus 2"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(41) : frmPiano.domusicstop(46)
                Case "Esus 2"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(42) : frmPiano.domusicstop(47)
                Case "Fsus 2"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(43) : frmPiano.domusicstop(48)
                Case "F#sus 2"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(44) : frmPiano.domusicstop(49)
                Case "Gsus 2"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(50)
                Case "G#sus 2"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(51)
                Case "Asus 2"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(52)
                Case "A#sus 2"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(53)
                Case "Bsus 2"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(54)
                               '--------------------------------
                Case "Csus 4"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(41) : frmPiano.domusicstop(43)
                Case "C#sus 4"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(42) : frmPiano.domusicstop(44)
                Case "Dsus 4"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45)
                Case "D#sus 4"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46)
                Case "Esus 4"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47)
                Case "Fsus 4"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48)
                Case "F#sus 4"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49)
                Case "Gsus 4"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50)
                Case "G#sus 4"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51)
                Case "Asus 4"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52)
                Case "A#sus 4"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53)
                Case "Bsus 4"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54)
                                '-----------------------
                Case "Cadd 2"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(38) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43)
                Case "C#add 2"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(39) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44)
                Case "Dadd 2"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(40) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45)
                Case "D#add 2"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(41) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46)
                Case "Eadd 2"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(42) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47)
                Case "Fadd 2"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48)
                Case "F#add 2"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49)
                Case "Gadd 2"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50)
                Case "G#add 2"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51)
                Case "Aadd 2"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52)
                Case "A#add 2"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53)
                Case "Badd 2"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54)
                                '-----------------------------------
                Case "Cadd 4"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(41) : frmPiano.domusicstop(43)
                Case "C#add 4"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(42) : frmPiano.domusicstop(44)
                Case "Dadd 4"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45)
                Case "D#add 4"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46)
                Case "Eadd 4"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47)
                Case "Fadd 4"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48)
                Case "F#add 4"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49)
                Case "Gadd 4"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50)
                Case "G#add 4"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51)
                Case "Aadd 4"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52)
                Case "A#add 4"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53)
                Case "Badd 4"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54)
                               '---------------------------------
                Case "Cadd 9"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(50)
                Case "C#add 9"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(51)
                Case "Dadd 9"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(52)
                Case "D#add 9"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(53)
                Case "Eadd 9"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(54)
                Case "Fadd 9"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(55)
                Case "F#add 9"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(56)
                Case "Gadd 9"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(57)
                Case "G#add 9"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(58)
                Case "Aadd 9"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(59)
                Case "A#add 9"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(60)
                Case "Badd 9"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(61)
                               '------------------------------
                Case "Cdim"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(42)
                Case "C#dim"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43)
                Case "Ddim"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44)
                Case "D#dim"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45)
                Case "Edim"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46)
                Case "Fdim"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47)
                Case "F#dim"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48)
                Case "Gdim"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49)
                Case "G#dim"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50)
                Case "Adim"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51)
                Case "A#dim"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52)
                Case "Bdim"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53)
                               '----------------------------------
                Case "Cdim 7"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45)
                Case "C#dim 7"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46)
                Case "Ddim 7"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47)
                Case "D#dim 7"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48)
                Case "Edim 7"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49)
                Case "Fdim 7"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50)
                Case "F#dim 7"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51)
                Case "Gdim 7"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52)
                Case "G#dim 7"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53)
                Case "Adim 7"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54)
                Case "A#dim 7"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55)
                Case "Bdim 7"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56)
                               '--------------------------------
                Case "Cdim add 4"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(41) : frmPiano.domusicstop(42)
                Case "C#dim add 4"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(42) : frmPiano.domusicstop(43)
                Case "Ddim add 4"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(43) : frmPiano.domusicstop(44)
                Case "D#dim add 4"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(44) : frmPiano.domusicstop(45)
                Case "Edim add 4"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(46)
                Case "Fdim add 4"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(47)
                Case "F#dim add 4"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(48)
                Case "Gdim add 4"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(49)
                Case "G#dim add 4"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(50)
                Case "Adim add 4"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(51)
                Case "A#dim add 4"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(52)
                Case "Bdim add 4"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52) : frmPiano.domusicstop(53)
                                '------------------------------
                Case "Cdim-Maj7"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(47)
                Case "C#dim-Maj7"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(48)
                Case "Ddim-Maj7"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(49)
                Case "D#dim-Maj7"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(50)
                Case "Edim-Maj7"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(51)
                Case "Fdim-Maj7"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(52)
                Case "F#dim-Maj7"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(53)
                Case "Gdim-Maj7"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(54)
                Case "G#dim-Maj7"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(55)
                Case "Adim-Maj7"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(56)
                Case "A#dim-Maj7"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(57)
                Case "Bdim-Maj7"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(58)
                              '------------------------------------
                Case "Caug"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(44)
                Case "C#aug"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(45)
                Case "Daug"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(46)
                Case "D#aug"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47)
                Case "Eaug"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48)
                Case "Faug"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49)
                Case "F#aug"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50)
                Case "Gaug"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51)
                Case "G#aug"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52)
                Case "Aaug"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53)
                Case "A#aug"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54)
                Case "Baug"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55)
                               '---------------------------------
                Case "Caug 6"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(45)
                Case "C#aug 6"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(46)
                Case "Daug 6"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(47)
                Case "D#aug 6"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(48)
                Case "Eaug 6"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(49)
                Case "Faug 6"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(50)
                Case "F#aug 6"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(51)
                Case "Gaug 6"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(52)
                Case "G#aug 6"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(53)
                Case "Aaug 6"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(54)
                Case "A#aug 6"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(55)
                Case "Baug 6"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55) : frmPiano.domusicstop(56)
                               '-------------------------------
                Case "Caug m11"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54)
                Case "C#aug m11"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55)
                Case "Daug m11"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56)
                Case "D#aug m11"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57)
                Case "Eaug m11"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58)
                Case "Faug m11"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55) : frmPiano.domusicstop(59)
                Case "F#aug m11"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56) : frmPiano.domusicstop(60)
                Case "Gaug m11"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57) : frmPiano.domusicstop(61)
                Case "G#aug m11"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58) : frmPiano.domusicstop(62)
                Case "Aaug m11"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55) : frmPiano.domusicstop(59) : frmPiano.domusicstop(63)
                Case "A#aug m11"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56) : frmPiano.domusicstop(60) : frmPiano.domusicstop(64)
                Case "Baug m11"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57) : frmPiano.domusicstop(61) : frmPiano.domusicstop(65)
                              '------------------------------
                Case "Cb9"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49)
                Case "C#b9"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50)
                Case "C#9"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51)
                Case "D#b9"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52)
                Case "Eb9"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53)
                Case "Fb9"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54)
                Case "F#b9"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55)
                Case "Gb9"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56)
                Case "G#b9"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57)
                Case "Ab9"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55) : frmPiano.domusicstop(58)
                Case "A#b9"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56) : frmPiano.domusicstop(59)
                Case "Bb9"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57) : frmPiano.domusicstop(60)
                                         '--------------------------------------------
                Case "Cb9 b5"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49)
                Case "C#b9 b5"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50)
                Case "C#9 b5"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51)
                Case "D#b9 b5"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52)
                Case "Eb9 b5"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53)
                Case "Fb9 b5"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54)
                Case "F#b9 b5"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55)
                Case "Gb9 b5"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56)
                Case "G#b9 b5"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57)
                Case "Ab9 b5"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55) : frmPiano.domusicstop(58)
                Case "A#b9 b5"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56) : frmPiano.domusicstop(59)
                Case "Bb9 b5"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57) : frmPiano.domusicstop(60)
                                      '---------------------------------
                Case "C5"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(43)
                Case "C#5"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(44)
                Case "D5"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(45)
                Case "D#5"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(46)
                Case "E5"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(47)
                Case "F5"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(48)
                Case "F#5"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(49)
                Case "G5"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(50)
                Case "G#5"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(51)
                Case "A5"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(52)
                Case "A#5"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(53)
                Case "B5"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(54)
                             '------------------------
                Case "C5 add7"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46)
                Case "C#5 add7"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47)
                Case "D5 add7"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48)
                Case "D#5 add7"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49)
                Case "E5 add7"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50)
                Case "F5 add7"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51)
                Case "F#5 add7"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52)
                Case "G5 add7"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53)
                Case "G#5 add7"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54)
                Case "A5 add7"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55)
                Case "A#5 add7"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56)
                Case "B5 add7"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57)
                                       '----------------------------
                Case "C6"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45)
                Case "C#6"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46)
                Case "D6"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47)
                Case "D#6"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48)
                Case "E6"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49)
                Case "F6"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50)
                Case "F#6"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51)
                Case "G6"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52)
                Case "G#6"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53)
                Case "A6"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54)
                Case "A#6"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(55)
                Case "B6"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(56)
                               '--------------------------
                Case "C6 add4"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(41) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45)
                Case "C#6 add4"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(42) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46)
                Case "D6 add4"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47)
                Case "D#6 add4"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48)
                Case "E6 add4"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49)
                Case "F6 add4"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50)
                Case "F#6 add4"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51)
                Case "G6 add4"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52)
                Case "G#6 add4"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53)
                Case "A6 add4"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54)
                Case "A#6 add4"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53) : frmPiano.domusicstop(55)
                Case "B6 add4"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54) : frmPiano.domusicstop(56)
                                     '---------------------
                Case "C6 add9"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(50)
                Case "C#6 add9"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(51)
                Case "D6 add9"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(52)
                Case "D#6 add9"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(53)
                Case "E6 add9"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(54)
                Case "F6 add9"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(55)
                Case "F#6 add9"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(56)
                Case "G6 add9"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52) : frmPiano.domusicstop(57)
                Case "G#6 add9"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53) : frmPiano.domusicstop(58)
                Case "A6 add9"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54) : frmPiano.domusicstop(59)
                Case "A#6 add9"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(55) : frmPiano.domusicstop(60)
                Case "B6 add9"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(56) : frmPiano.domusicstop(61)
                              '----------------------------
                Case "C6 sus"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45)
                Case "C#6 sus"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46)
                Case "D6 sus"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47)
                Case "D#6 sus"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48)
                Case "E6 sus"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49)
                Case "F6 sus"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50)
                Case "F#6 sus"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51)
                Case "G6 sus"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52)
                Case "G#6 sus"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53)
                Case "A6 sus"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54)
                Case "A#6 sus"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(53) : frmPiano.domusicstop(55)
                Case "B6 sus"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(54) : frmPiano.domusicstop(56)
                            '-------------------
                Case "C6 b5"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45)
                Case "C#6 b5"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46)
                Case "D6 b5"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47)
                Case "D#6 b5"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48)
                Case "E6 b5"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49)
                Case "F6 b5"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50)
                Case "F#6 b5"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51)
                Case "G6 b5"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52)
                Case "G#6 b5"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53)
                Case "A6 b5"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54)
                Case "A#6 b5"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55)
                Case "B6 b5"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56)
                            '--------------------
                Case "C7 sus"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46)
                Case "C#7 sus"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47)
                Case "D7 sus"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48)
                Case "D#7 sus"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49)
                Case "E7 sus"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50)
                Case "F7 sus"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51)
                Case "F#7 sus"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52)
                Case "G7 sus"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53)
                Case "G#7 sus"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54)
                Case "A7 sus"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55)
                Case "A#7 sus"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56)
                Case "B7 sus"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57)
                         '---------------------
                Case "C7 sus2"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(38) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46)
                Case "C#7 sus2"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(39) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47)
                Case "D7 sus2"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(40) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48)
                Case "D#7 sus2"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(41) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49)
                Case "E7 sus2"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(42) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50)
                Case "F7 sus2"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(43) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51)
                Case "F#7 sus2"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(44) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52)
                Case "G7 sus2"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53)
                Case "G#7 sus2"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54)
                Case "A7 sus2"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55)
                Case "A#7 sus2"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56)
                Case "B7 sus2"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57)
                            '----------------------
                Case "C7 sus4"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(41) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46)
                Case "C#7 sus4"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(42) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47)
                Case "D7 sus4"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48)
                Case "D#7 sus4"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49)
                Case "E7 sus4"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50)
                Case "F7 sus4"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51)
                Case "F#7 sus4"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52)
                Case "G7 sus4"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53)
                Case "G#7 sus4"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54)
                Case "A7 sus4"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55)
                Case "A#7 sus4"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56)
                Case "B7 sus4"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57)
                             '---------------------
                Case "C7 b5"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(42) : frmPiano.domusicstop(46)
                Case "C#7 b5"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47)
                Case "D7 b5"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48)
                Case "D#7 b5"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49)
                Case "E7 b5"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50)
                Case "F7 b5"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51)
                Case "F#7 b5"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52)
                Case "G7 b5"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53)
                Case "G#7 b5"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54)
                Case "A7 b5"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55)
                Case "A#7 b5"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56)
                Case "B7 b5"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57)
                             '----------------------
                Case "C7 #5"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46)
                Case "C#7 #5"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47)
                Case "D7 #5"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48)
                Case "D#7 #5"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49)
                Case "E7 #5"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50)
                Case "F7 #5"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51)
                Case "F#7 #5"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52)
                Case "G7 #5"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53)
                Case "G#7 #5"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54)
                Case "A7 #5"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(55)
                Case "A#7 #5"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(56)
                Case "B7 #5"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55) : frmPiano.domusicstop(57)
                             '----------------------
                Case "C7 b9"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49)
                Case "C#7 b9"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50)
                Case "D7 b9"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51)
                Case "D#7 b9"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52)
                Case "E7 b9"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53)
                Case "F7 b9"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54)
                Case "F#7 b9"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55)
                Case "G7 b9"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56)
                Case "G#7 b9"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57)
                Case "A7 b9"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55) : frmPiano.domusicstop(58)
                Case "A#7 b9"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56) : frmPiano.domusicstop(59)
                Case "B7 b9"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57) : frmPiano.domusicstop(60)
                              '----------------------
                Case "C7 #9"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(51)
                Case "C#7 #9"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(52)
                Case "D7 #9"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(53)
                Case "D#7 #9"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(54)
                Case "E7 #9"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(55)
                Case "F7 #9"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(56)
                Case "F#7 #9"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(57)
                Case "G7 #9"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(58)
                Case "G#7 #9"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(59)
                Case "A7 #9"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55) : frmPiano.domusicstop(60)
                Case "A#7 #9"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56) : frmPiano.domusicstop(61)
                Case "B7 #9"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57) : frmPiano.domusicstop(62)
                             '------------------------
                Case "C7 #11"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(54)
                Case "C#7 #11"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(55)
                Case "D7 #11"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(56)
                Case "D#7 #11"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(57)
                Case "E7 #11"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(58)
                Case "F7 #11"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(59)
                Case "F#7 #11"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(60)
                Case "G7 #11"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(61)
                Case "G#7 #11"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(62)
                Case "A7 #11"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55) : frmPiano.domusicstop(63)
                Case "A#7 #11"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56) : frmPiano.domusicstop(64)
                Case "B7 #11"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57) : frmPiano.domusicstop(65)
                              '----------------------
                Case "C7-6"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(46)
                Case "C#7-6"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(47)
                Case "D7-6"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(48)
                Case "D#7-6"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(49)
                Case "E7-6"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(50)
                Case "F7-6"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(51)
                Case "F#7-6"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(52)
                Case "G7-6"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52) : frmPiano.domusicstop(53)
                Case "G#7-6"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53) : frmPiano.domusicstop(54)
                Case "A7-6"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54) : frmPiano.domusicstop(55)
                Case "A#7-6"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(55) : frmPiano.domusicstop(56)
                Case "B7-6"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(56) : frmPiano.domusicstop(57)
                             '----------------------
                Case "C7-9"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49)
                Case "C#7-9"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50)
                Case "D7-9"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51)
                Case "D#7-9"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52)
                Case "E7-9"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53)
                Case "F7-9"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54)
                Case "F#7-9"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55)
                Case "G7-9"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56)
                Case "G#7-9"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57)
                Case "A7-9"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55) : frmPiano.domusicstop(58)
                Case "A#7-9"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56) : frmPiano.domusicstop(59)
                Case "B7-9"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57) : frmPiano.domusicstop(60)
                             '--------------------
                Case "C7-13"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(57)
                Case "C#7-13"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(58)
                Case "D7-13"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(59)
                Case "D#7-13"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(60)
                Case "E7-13"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(61)
                Case "F7-13"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(62)
                Case "F#7-13"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(63)
                Case "G7-13"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(64)
                Case "G#7-13"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(65)
                Case "A7-13"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55) : frmPiano.domusicstop(66)
                Case "A#7-13"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56) : frmPiano.domusicstop(67)
                Case "B7-13"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57) : frmPiano.domusicstop(68)
                        '---------------------
                Case "C9"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50)
                Case "C#9"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51)
                Case "D9"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52)
                Case "D#9"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53)
                Case "E9"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54)
                Case "F9"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55)
                Case "F#9"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56)
                Case "G9"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57)
                Case "G#9"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58)
                Case "A9"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55) : frmPiano.domusicstop(59)
                Case "A#9"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56) : frmPiano.domusicstop(60)
                Case "B9"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57) : frmPiano.domusicstop(61)
                             '---------------------
                Case "C9 sus"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(38) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46)
                Case "C#9 sus"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(39) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47)
                Case "D9 sus"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(40) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48)
                Case "D#9 sus"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(41) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49)
                Case "E9 sus"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(42) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50)
                Case "F9 sus"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(43) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51)
                Case "F#9 sus"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(44) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52)
                Case "G9 sus"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53)
                Case "G#9 sus"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54)
                Case "A9 sus"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55)
                Case "A#9 sus"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56)
                Case "B9 sus"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57)
                            '-----------------------
                Case "C9 sus4"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(41) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50)
                Case "C#9 sus4"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(42) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51)
                Case "D9 sus4"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52)
                Case "D#9 sus4"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53)
                Case "E9 sus4"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54)
                Case "F9 sus4"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55)
                Case "F#9 sus4"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56)
                Case "G9 sus4"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57)
                Case "G#9 sus4"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58)
                Case "A9 sus4"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55) : frmPiano.domusicstop(59)
                Case "A#9 sus4"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56) : frmPiano.domusicstop(60)
                Case "B9 sus4"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57) : frmPiano.domusicstop(61)
                               '-------------------
                Case "C9 b5"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50)
                Case "C#9 b5"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51)
                Case "D9 b5"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52)
                Case "D#9 b5"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53)
                Case "E9 b5"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54)
                Case "F9 b5"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55)
                Case "F#9 b5"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56)
                Case "G9 b5"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57)
                Case "G#9 b5"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58)
                Case "A9 b5"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55) : frmPiano.domusicstop(59)
                Case "A#9 b5"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56) : frmPiano.domusicstop(60)
                Case "B9 b5"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57) : frmPiano.domusicstop(61)
                              '----------------------
                Case "C11"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53)
                Case "C#11"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54)
                Case "D11"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55)
                Case "D#11"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56)
                Case "E11"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57)
                Case "F11"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55) : frmPiano.domusicstop(58)
                Case "F#11"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56) : frmPiano.domusicstop(59)
                Case "G11"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57) : frmPiano.domusicstop(60)
                Case "G#11"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58) : frmPiano.domusicstop(61)
                Case "A11"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55) : frmPiano.domusicstop(59) : frmPiano.domusicstop(62)
                Case "A#11"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56) : frmPiano.domusicstop(60) : frmPiano.domusicstop(63)
                Case "B11"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57) : frmPiano.domusicstop(61) : frmPiano.domusicstop(64)
                              '---------------------
                Case "C-#11"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(54)
                Case "C#-#11"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(55)
                Case "D-#11"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(56)
                Case "D#-#11"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(57)
                Case "E-#11"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(58)
                Case "F-#11"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(59)
                Case "F#-#11"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(60)
                Case "G-#11"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(61)
                Case "G#-#11"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(62)
                Case "A-#11"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(63)
                Case "A#-#11"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(64)
                Case "B-#11"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(65)
                      '----------------------
                Case "C11 sus4"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(41) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53)
                Case "C#11 sus4"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(42) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54)
                Case "D11 sus4"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(43) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55)
                Case "D#11 sus4"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(44) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56)
                Case "E11 sus4"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(45) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57)
                Case "F11 sus4"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(46) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55) : frmPiano.domusicstop(58)
                Case "F#11 sus4"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(47) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56) : frmPiano.domusicstop(59)
                Case "G11 sus4"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(48) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57) : frmPiano.domusicstop(60)
                Case "G#11 sus4"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(49) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58) : frmPiano.domusicstop(61)
                Case "A11 sus4"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(50) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55) : frmPiano.domusicstop(59) : frmPiano.domusicstop(62)
                Case "A#11 sus4"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(51) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56) : frmPiano.domusicstop(60) : frmPiano.domusicstop(63)
                Case "B11 sus4"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(52) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57) : frmPiano.domusicstop(61) : frmPiano.domusicstop(64)
                             '--------------------
                Case "C13"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57)
                Case "C#13"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58)
                Case "D13"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55) : frmPiano.domusicstop(59)
                Case "D#13"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56) : frmPiano.domusicstop(60)
                Case "E13"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57) : frmPiano.domusicstop(61)
                Case "F13"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55) : frmPiano.domusicstop(58) : frmPiano.domusicstop(62)
                Case "F#13"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56) : frmPiano.domusicstop(59) : frmPiano.domusicstop(63)
                Case "G13"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57) : frmPiano.domusicstop(60) : frmPiano.domusicstop(64)
                Case "G#13"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58) : frmPiano.domusicstop(61) : frmPiano.domusicstop(65)
                Case "A13"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55) : frmPiano.domusicstop(59) : frmPiano.domusicstop(62) : frmPiano.domusicstop(66)
                Case "A#13"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56) : frmPiano.domusicstop(60) : frmPiano.domusicstop(63) : frmPiano.domusicstop(67)
                Case "B13"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57) : frmPiano.domusicstop(61) : frmPiano.domusicstop(64) : frmPiano.domusicstop(68)
                           '------------------------
                Case "C13 #11"
                    frmPiano.domusicstop(36) : frmPiano.domusicstop(40) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57)
                Case "C#13 #11"
                    frmPiano.domusicstop(37) : frmPiano.domusicstop(41) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55) : frmPiano.domusicstop(58)
                Case "D13 #11"
                    frmPiano.domusicstop(38) : frmPiano.domusicstop(42) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56) : frmPiano.domusicstop(59)
                Case "D#13 #11"
                    frmPiano.domusicstop(39) : frmPiano.domusicstop(43) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57) : frmPiano.domusicstop(60)
                Case "E13 #11"
                    frmPiano.domusicstop(40) : frmPiano.domusicstop(44) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58) : frmPiano.domusicstop(61)
                Case "F13 #11"
                    frmPiano.domusicstop(41) : frmPiano.domusicstop(45) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(55) : frmPiano.domusicstop(59) : frmPiano.domusicstop(62)
                Case "F#13 #11"
                    frmPiano.domusicstop(42) : frmPiano.domusicstop(46) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(56) : frmPiano.domusicstop(60) : frmPiano.domusicstop(63)
                Case "G13 #11"
                    frmPiano.domusicstop(43) : frmPiano.domusicstop(47) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(57) : frmPiano.domusicstop(61) : frmPiano.domusicstop(64)
                Case "G#13 #11"
                    frmPiano.domusicstop(44) : frmPiano.domusicstop(48) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(58) : frmPiano.domusicstop(62) : frmPiano.domusicstop(65)
                Case "A13 #11"
                    frmPiano.domusicstop(45) : frmPiano.domusicstop(49) : frmPiano.domusicstop(52) : frmPiano.domusicstop(55) : frmPiano.domusicstop(59) : frmPiano.domusicstop(63) : frmPiano.domusicstop(66)
                Case "A#13 #11"
                    frmPiano.domusicstop(46) : frmPiano.domusicstop(50) : frmPiano.domusicstop(53) : frmPiano.domusicstop(56) : frmPiano.domusicstop(60) : frmPiano.domusicstop(64) : frmPiano.domusicstop(67)
                Case "B13 #11"
                    frmPiano.domusicstop(47) : frmPiano.domusicstop(51) : frmPiano.domusicstop(54) : frmPiano.domusicstop(57) : frmPiano.domusicstop(61) : frmPiano.domusicstop(65) : frmPiano.domusicstop(68)


            End Select
        End Function






    End Module